﻿<!DOCTYPE html>
<html>
<body>

<?php


print_r($_GET);


echo "<br>";echo "<br>";echo "<br>";
$tabelka=implode("-",$_GET["T"]);
echo $tabelka;
echo "<br>";echo "<br>";echo "<br>";
$tekst=implode(";",$_GET);

$tekst=preg_replace("/world/","Peter",$tekst,1);
echo $tekst."<br>";
$tekst=preg_replace("/Array/",$tabelka,$tekst,1);
echo $tekst."<br>";

?>


</body>
</html>
