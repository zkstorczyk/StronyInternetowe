<?php
session_start();
$_SESSION["kod"] = $_GET["firstname"];
?>


<html xmlns:v="urn:schemas-microsoft-com:vml"
xmlns:o="urn:schemas-microsoft-com:office:office"
xmlns:w="urn:schemas-microsoft-com:office:word"
xmlns:m="http://schemas.microsoft.com/office/2004/12/omml"
xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta charset="UTF-8">
<meta http-equiv=Content-Type content="text/html; charset=windows-1250">
<meta name=ProgId content=Word.Document>
<meta name=Generator content="Microsoft Word 14">
<meta name=Originator content="Microsoft Word 14">
<link rel=File-List href="pytania1_pliki/filelist.xml">
<!--[if gte mso 9]><xml>
 <o:DocumentProperties>
  <o:Author>PA</o:Author>
  <o:Template>Normal</o:Template>
  <o:LastAuthor>UKW</o:LastAuthor>
  <o:Revision>2</o:Revision>
  <o:TotalTime>269</o:TotalTime>
  <o:Created>2016-04-06T06:19:00Z</o:Created>
  <o:LastSaved>2016-04-06T06:19:00Z</o:LastSaved>
  <o:Pages>6</o:Pages>
  <o:Words>1127</o:Words>
  <o:Characters>6763</o:Characters>
  <o:Company>PA</o:Company>
  <o:Lines>56</o:Lines>
  <o:Paragraphs>15</o:Paragraphs>
  <o:CharactersWithSpaces>7875</o:CharactersWithSpaces>
  <o:Version>14.00</o:Version>
 </o:DocumentProperties>
 <o:OfficeDocumentSettings>
  <o:AllowPNG/>
 </o:OfficeDocumentSettings>
</xml><![endif]-->
<link rel=dataStoreItem href="pytania1_pliki/item0001.xml"
target="pytania1_pliki/props002.xml">
<link rel=themeData href="pytania1_pliki/themedata.thmx">
<link rel=colorSchemeMapping href="pytania1_pliki/colorschememapping.xml">
<!--[if gte mso 9]><xml>
 <w:WordDocument>
  <w:SpellingState>Clean</w:SpellingState>
  <w:TrackMoves>false</w:TrackMoves>
  <w:TrackFormatting/>
  <w:HyphenationZone>21</w:HyphenationZone>
  <w:PunctuationKerning/>
  <w:ValidateAgainstSchemas/>
  <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>
  <w:IgnoreMixedContent>false</w:IgnoreMixedContent>
  <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>
  <w:DoNotPromoteQF/>
  <w:LidThemeOther>PL</w:LidThemeOther>
  <w:LidThemeAsian>JA</w:LidThemeAsian>
  <w:LidThemeComplexScript>X-NONE</w:LidThemeComplexScript>
  <w:Compatibility>
   <w:BreakWrappedTables/>
   <w:SnapToGridInCell/>
   <w:WrapTextWithPunct/>
   <w:UseAsianBreakRules/>
   <w:DontGrowAutofit/>
   <w:SplitPgBreakAndParaMark/>
   <w:EnableOpenTypeKerning/>
   <w:DontFlipMirrorIndents/>
   <w:OverrideTableStyleHps/>
  </w:Compatibility>
  <m:mathPr>
   <m:mathFont m:val="Cambria Math"/>
   <m:brkBin m:val="before"/>
   <m:brkBinSub m:val="&#45;-"/>
   <m:smallFrac m:val="off"/>
   <m:dispDef/>
   <m:lMargin m:val="0"/>
   <m:rMargin m:val="0"/>
   <m:defJc m:val="centerGroup"/>
   <m:wrapIndent m:val="1440"/>
   <m:intLim m:val="subSup"/>
   <m:naryLim m:val="undOvr"/>
  </m:mathPr></w:WordDocument>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <w:LatentStyles DefLockedState="false" DefUnhideWhenUsed="true"
  DefSemiHidden="true" DefQFormat="false" DefPriority="99"
  LatentStyleCount="267">
  <w:LsdException Locked="false" Priority="0" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Normal"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="heading 1"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 2"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 3"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 4"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 5"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 6"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 7"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 8"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 9"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 1"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 2"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 3"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 4"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 5"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 6"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 7"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 8"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 9"/>
  <w:LsdException Locked="false" Priority="35" QFormat="true" Name="caption"/>
  <w:LsdException Locked="false" Priority="10" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Title"/>
  <w:LsdException Locked="false" Priority="1" Name="Default Paragraph Font"/>
  <w:LsdException Locked="false" Priority="11" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Subtitle"/>
  <w:LsdException Locked="false" Priority="22" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Strong"/>
  <w:LsdException Locked="false" Priority="20" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Emphasis"/>
  <w:LsdException Locked="false" Priority="59" SemiHidden="false"
   UnhideWhenUsed="false" Name="Table Grid"/>
  <w:LsdException Locked="false" UnhideWhenUsed="false" Name="Placeholder Text"/>
  <w:LsdException Locked="false" Priority="1" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="No Spacing"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 1"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 1"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 1"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 1"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 1"/>
  <w:LsdException Locked="false" UnhideWhenUsed="false" Name="Revision"/>
  <w:LsdException Locked="false" Priority="0" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="List Paragraph"/>
  <w:LsdException Locked="false" Priority="29" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Quote"/>
  <w:LsdException Locked="false" Priority="30" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Intense Quote"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 1"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 1"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 1"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 1"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 1"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 1"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 2"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 2"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 2"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 2"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 2"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 2"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 2"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 2"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 2"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 2"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 2"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 3"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 3"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 3"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 3"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 3"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 3"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 3"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 3"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 3"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 3"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 3"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 4"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 4"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 4"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 4"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 4"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 4"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 4"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 4"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 4"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 4"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 4"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 5"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 5"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 5"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 5"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 5"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 5"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 5"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 5"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 5"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 5"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 5"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 6"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 6"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 6"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 6"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 6"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 6"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 6"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 6"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 6"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 6"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 6"/>
  <w:LsdException Locked="false" Priority="19" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Subtle Emphasis"/>
  <w:LsdException Locked="false" Priority="21" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Intense Emphasis"/>
  <w:LsdException Locked="false" Priority="31" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Subtle Reference"/>
  <w:LsdException Locked="false" Priority="32" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Intense Reference"/>
  <w:LsdException Locked="false" Priority="33" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Book Title"/>
  <w:LsdException Locked="false" Priority="37" Name="Bibliography"/>
  <w:LsdException Locked="false" Priority="39" QFormat="true" Name="TOC Heading"/>
 </w:LatentStyles>
</xml><![endif]-->
<style>
<!--
 /* Font Definitions */
 @font-face
	{font-family:Helvetica;
	panose-1:2 11 5 4 2 2 2 2 2 4;
	mso-font-charset:0;
	mso-generic-font-family:swiss;
	mso-font-format:other;
	mso-font-pitch:variable;
	mso-font-signature:3 0 0 0 1 0;}
@font-face
	{font-family:Wingdings;
	panose-1:5 0 0 0 0 0 0 0 0 0;
	mso-font-charset:2;
	mso-generic-font-family:auto;
	mso-font-pitch:variable;
	mso-font-signature:0 268435456 0 0 -2147483648 0;}
@font-face
	{font-family:Wingdings;
	panose-1:5 0 0 0 0 0 0 0 0 0;
	mso-font-charset:2;
	mso-generic-font-family:auto;
	mso-font-pitch:variable;
	mso-font-signature:0 268435456 0 0 -2147483648 0;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;
	mso-font-charset:238;
	mso-generic-font-family:swiss;
	mso-font-pitch:variable;
	mso-font-signature:-536870145 1073786111 1 0 415 0;}
@font-face
	{font-family:Tahoma;
	panose-1:2 11 6 4 3 5 4 4 2 4;
	mso-font-charset:238;
	mso-generic-font-family:swiss;
	mso-font-pitch:variable;
	mso-font-signature:-520081665 -1073717157 41 0 66047 0;}
@font-face
	{font-family:Times;
	panose-1:2 2 6 3 5 4 5 2 3 4;
	mso-font-charset:238;
	mso-generic-font-family:roman;
	mso-font-pitch:variable;
	mso-font-signature:-536858881 -1073711037 9 0 511 0;}
@font-face
	{font-family:KvhlnfTimesNewRomanPSMT;
	panose-1:0 0 0 0 0 0 0 0 0 0;
	mso-font-alt:"Times New Roman";
	mso-font-charset:0;
	mso-generic-font-family:roman;
	mso-font-format:other;
	mso-font-pitch:auto;
	mso-font-signature:3 0 0 0 1 0;}
@font-face
	{font-family:TTE10FF940t00;
	panose-1:0 0 0 0 0 0 0 0 0 0;
	mso-font-alt:"Times New Roman";
	mso-font-charset:0;
	mso-generic-font-family:auto;
	mso-font-format:other;
	mso-font-pitch:auto;
	mso-font-signature:3 0 0 0 1 0;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-parent:"";
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:10.0pt;
	margin-left:0cm;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:Calibri;
	mso-fareast-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-fareast-language:EN-US;}
h3
	{mso-style-priority:9;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-link:"Nag��wek 3 Znak";
	mso-margin-top-alt:auto;
	margin-right:0cm;
	mso-margin-bottom-alt:auto;
	margin-left:0cm;
	mso-pagination:widow-orphan;
	mso-outline-level:3;
	font-size:13.5pt;
	font-family:"Times New Roman","serif";
	mso-fareast-font-family:"Times New Roman";
	font-weight:bold;}
p.MsoPlainText, li.MsoPlainText, div.MsoPlainText
	{mso-style-priority:99;
	mso-style-link:"Zwyk�y tekst Znak";
	margin:0cm;
	margin-bottom:.0001pt;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	mso-bidi-font-size:10.5pt;
	font-family:"Calibri","sans-serif";
	mso-fareast-font-family:Calibri;
	mso-fareast-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-fareast-language:EN-US;}
p
	{mso-style-priority:99;
	mso-margin-top-alt:auto;
	margin-right:0cm;
	mso-margin-bottom-alt:auto;
	margin-left:0cm;
	mso-pagination:widow-orphan;
	font-size:12.0pt;
	font-family:"Times New Roman","serif";
	mso-fareast-font-family:Calibri;
	mso-fareast-theme-font:minor-latin;}
pre
	{mso-style-priority:99;
	mso-style-link:"HTML - wst�pnie sformatowany Znak";
	margin:0cm;
	margin-bottom:.0001pt;
	mso-pagination:widow-orphan;
	tab-stops:45.8pt 91.6pt 137.4pt 183.2pt 229.0pt 274.8pt 320.6pt 366.4pt 412.2pt 458.0pt 503.8pt 549.6pt 595.4pt 641.2pt 687.0pt 732.8pt;
	font-size:10.0pt;
	font-family:"Courier New";
	mso-fareast-font-family:"Times New Roman";}
p.MsoAcetate, li.MsoAcetate, div.MsoAcetate
	{mso-style-noshow:yes;
	mso-style-priority:99;
	mso-style-link:"Tekst dymka Znak";
	margin:0cm;
	margin-bottom:.0001pt;
	mso-pagination:widow-orphan;
	font-size:8.0pt;
	font-family:"Tahoma","sans-serif";
	mso-fareast-font-family:Calibri;
	mso-fareast-theme-font:minor-latin;
	mso-fareast-language:EN-US;}
p.MsoListParagraph, li.MsoListParagraph, div.MsoListParagraph
	{mso-style-unhide:no;
	mso-style-qformat:yes;
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:10.0pt;
	margin-left:36.0pt;
	mso-add-space:auto;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:Calibri;
	mso-fareast-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-fareast-language:EN-US;}
p.MsoListParagraphCxSpFirst, li.MsoListParagraphCxSpFirst, div.MsoListParagraphCxSpFirst
	{mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-type:export-only;
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:36.0pt;
	margin-bottom:.0001pt;
	mso-add-space:auto;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:Calibri;
	mso-fareast-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-fareast-language:EN-US;}
p.MsoListParagraphCxSpMiddle, li.MsoListParagraphCxSpMiddle, div.MsoListParagraphCxSpMiddle
	{mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-type:export-only;
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:36.0pt;
	margin-bottom:.0001pt;
	mso-add-space:auto;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:Calibri;
	mso-fareast-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-fareast-language:EN-US;}
p.MsoListParagraphCxSpLast, li.MsoListParagraphCxSpLast, div.MsoListParagraphCxSpLast
	{mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-type:export-only;
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:10.0pt;
	margin-left:36.0pt;
	mso-add-space:auto;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:Calibri;
	mso-fareast-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-fareast-language:EN-US;}
span.HTML-wstpniesformatowanyZnak
	{mso-style-name:"HTML - wst�pnie sformatowany Znak";
	mso-style-priority:99;
	mso-style-unhide:no;
	mso-style-locked:yes;
	mso-style-link:"HTML - wst�pnie sformatowany";
	mso-ansi-font-size:10.0pt;
	mso-bidi-font-size:10.0pt;
	font-family:"Courier New";
	mso-ascii-font-family:"Courier New";
	mso-fareast-font-family:"Times New Roman";
	mso-hansi-font-family:"Courier New";
	mso-bidi-font-family:"Courier New";
	mso-fareast-language:PL;}
span.hps
	{mso-style-name:hps;
	mso-style-unhide:no;}
span.shorttext
	{mso-style-name:short_text;
	mso-style-unhide:no;}
span.ZwykytekstZnak
	{mso-style-name:"Zwyk�y tekst Znak";
	mso-style-priority:99;
	mso-style-unhide:no;
	mso-style-locked:yes;
	mso-style-link:"Zwyk�y tekst";
	mso-bidi-font-size:10.5pt;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-hansi-font-family:Calibri;}
p.Default, li.Default, div.Default
	{mso-style-name:Default;
	mso-style-unhide:no;
	mso-style-parent:"";
	margin:0cm;
	margin-bottom:.0001pt;
	mso-pagination:widow-orphan;
	mso-layout-grid-align:none;
	text-autospace:none;
	font-size:12.0pt;
	font-family:"Times New Roman","serif";
	mso-fareast-font-family:Calibri;
	mso-fareast-theme-font:minor-latin;
	color:black;
	mso-fareast-language:EN-US;}
span.Nagwek3Znak
	{mso-style-name:"Nag��wek 3 Znak";
	mso-style-priority:9;
	mso-style-unhide:no;
	mso-style-locked:yes;
	mso-style-link:"Nag��wek 3";
	mso-ansi-font-size:13.5pt;
	mso-bidi-font-size:13.5pt;
	font-family:"Times New Roman","serif";
	mso-ascii-font-family:"Times New Roman";
	mso-fareast-font-family:"Times New Roman";
	mso-hansi-font-family:"Times New Roman";
	mso-bidi-font-family:"Times New Roman";
	mso-fareast-language:PL;
	font-weight:bold;}
span.TekstdymkaZnak
	{mso-style-name:"Tekst dymka Znak";
	mso-style-noshow:yes;
	mso-style-priority:99;
	mso-style-unhide:no;
	mso-style-locked:yes;
	mso-style-link:"Tekst dymka";
	mso-ansi-font-size:8.0pt;
	mso-bidi-font-size:8.0pt;
	font-family:"Tahoma","sans-serif";
	mso-ascii-font-family:Tahoma;
	mso-hansi-font-family:Tahoma;
	mso-bidi-font-family:Tahoma;}
span.SpellE
	{mso-style-name:"";
	mso-spl-e:yes;}
.MsoChpDefault
	{mso-style-type:export-only;
	mso-default-props:yes;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:Calibri;
	mso-fareast-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-fareast-language:EN-US;}
.MsoPapDefault
	{mso-style-type:export-only;
	margin-bottom:10.0pt;
	line-height:115%;}
@page WordSection1
	{size:595.3pt 841.9pt;
	margin:70.85pt 70.85pt 70.85pt 70.85pt;
	mso-header-margin:35.4pt;
	mso-footer-margin:35.4pt;
	mso-paper-source:0;}
div.WordSection1
	{page:WordSection1;}
 /* List Definitions */
 @list l0
	{mso-list-id:1;
	mso-list-type:simple;
	mso-list-template-ids:1;
	mso-list-name:WW8Num1;}
@list l0:level1
	{mso-level-tab-stop:0cm;
	mso-level-number-position:left;
	margin-left:18.0pt;
	text-indent:-18.0pt;}
@list l1
	{mso-list-id:151261612;
	mso-list-type:hybrid;
	mso-list-template-ids:-974514584 843375254 68485145 68485147 68485135 68485145 68485147 68485135 68485145 68485147;}
@list l1:level1
	{mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:18.0pt;
	text-indent:-18.0pt;
	mso-ansi-font-weight:bold;}
@list l1:level2
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:54.0pt;
	text-indent:-18.0pt;}
@list l1:level3
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:right;
	margin-left:90.0pt;
	text-indent:-9.0pt;}
@list l1:level4
	{mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:126.0pt;
	text-indent:-18.0pt;}
@list l1:level5
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:162.0pt;
	text-indent:-18.0pt;}
@list l1:level6
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:right;
	margin-left:198.0pt;
	text-indent:-9.0pt;}
@list l1:level7
	{mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:234.0pt;
	text-indent:-18.0pt;}
@list l1:level8
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:270.0pt;
	text-indent:-18.0pt;}
@list l1:level9
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:right;
	margin-left:306.0pt;
	text-indent:-9.0pt;}
@list l2
	{mso-list-id:159661552;
	mso-list-template-ids:-449689670;}
@list l2:level1
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:36.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Symbol;}
@list l2:level2
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:72.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:"Courier New";
	mso-bidi-font-family:"Times New Roman";}
@list l2:level3
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:108.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l2:level4
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:144.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l2:level5
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:180.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l2:level6
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:216.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l2:level7
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:252.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l2:level8
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:288.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l2:level9
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:324.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l3
	{mso-list-id:326441754;
	mso-list-template-ids:-752573962;}
@list l3:level1
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:36.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Symbol;}
@list l3:level2
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:72.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:"Courier New";
	mso-bidi-font-family:"Times New Roman";}
@list l3:level3
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:108.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l3:level4
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:144.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l3:level5
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:180.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l3:level6
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:216.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l3:level7
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:252.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l3:level8
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:288.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l3:level9
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:324.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l4
	{mso-list-id:450438493;
	mso-list-type:hybrid;
	mso-list-template-ids:1349391546 629604344 68485123 68485125 68485121 68485123 68485125 68485121 68485123 68485125;}
@list l4:level1
	{mso-level-number-format:bullet;
	mso-level-text:\F0F0;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:18.0pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l4:level2
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:54.0pt;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l4:level3
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:90.0pt;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l4:level4
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:126.0pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l4:level5
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:162.0pt;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l4:level6
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:198.0pt;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l4:level7
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:234.0pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l4:level8
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:270.0pt;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l4:level9
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:306.0pt;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l5
	{mso-list-id:462432367;
	mso-list-type:hybrid;
	mso-list-template-ids:-1319632458 629604344 68485123 68485125 68485121 68485123 68485125 68485121 68485123 68485125;}
@list l5:level1
	{mso-level-number-format:bullet;
	mso-level-text:\F0F0;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:18.0pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l5:level2
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:54.0pt;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l5:level3
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:90.0pt;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l5:level4
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:126.0pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l5:level5
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:162.0pt;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l5:level6
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:198.0pt;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l5:level7
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:234.0pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l5:level8
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:270.0pt;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l5:level9
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:306.0pt;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l6
	{mso-list-id:502164015;
	mso-list-template-ids:-1174627662;}
@list l6:level1
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:36.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Symbol;}
@list l6:level2
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:72.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:"Courier New";
	mso-bidi-font-family:"Times New Roman";}
@list l6:level3
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:108.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l6:level4
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:144.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l6:level5
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:180.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l6:level6
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:216.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l6:level7
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:252.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l6:level8
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:288.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l6:level9
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:324.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l7
	{mso-list-id:542326282;
	mso-list-type:hybrid;
	mso-list-template-ids:-2027530714 629604344 68485123 68485125 68485121 68485123 68485125 68485121 68485123 68485125;}
@list l7:level1
	{mso-level-number-format:bullet;
	mso-level-text:\F0F0;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l7:level2
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l7:level3
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l7:level4
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l7:level5
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l7:level6
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l7:level7
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l7:level8
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l7:level9
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l8
	{mso-list-id:652758806;
	mso-list-type:hybrid;
	mso-list-template-ids:1781071666 629604344 68485123 68485125 68485121 68485123 68485125 68485121 68485123 68485125;}
@list l8:level1
	{mso-level-number-format:bullet;
	mso-level-text:\F0F0;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:18.0pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l8:level2
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:54.0pt;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l8:level3
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:90.0pt;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l8:level4
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:126.0pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l8:level5
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:162.0pt;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l8:level6
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:198.0pt;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l8:level7
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:234.0pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l8:level8
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:270.0pt;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l8:level9
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:306.0pt;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l9
	{mso-list-id:666790865;
	mso-list-template-ids:595232224;}
@list l9:level1
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:36.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Symbol;}
@list l9:level2
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:72.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:"Courier New";
	mso-bidi-font-family:"Times New Roman";}
@list l9:level3
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:108.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l9:level4
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:144.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l9:level5
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:180.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l9:level6
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:216.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l9:level7
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:252.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l9:level8
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:288.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l9:level9
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:324.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l10
	{mso-list-id:737361145;
	mso-list-type:hybrid;
	mso-list-template-ids:-1558001302 629604344 68485123 68485125 68485121 68485123 68485125 68485121 68485123 68485125;}
@list l10:level1
	{mso-level-number-format:bullet;
	mso-level-text:\F0F0;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:18.0pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l10:level2
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:54.0pt;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l10:level3
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:90.0pt;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l10:level4
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:126.0pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l10:level5
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:162.0pt;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l10:level6
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:198.0pt;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l10:level7
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:234.0pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l10:level8
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:270.0pt;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l10:level9
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:306.0pt;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l11
	{mso-list-id:778060287;
	mso-list-template-ids:538485928;}
@list l11:level1
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:36.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Symbol;}
@list l11:level2
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:72.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:"Courier New";
	mso-bidi-font-family:"Times New Roman";}
@list l11:level3
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:108.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l11:level4
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:144.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l11:level5
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:180.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l11:level6
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:216.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l11:level7
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:252.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l11:level8
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:288.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l11:level9
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:324.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l12
	{mso-list-id:817376648;
	mso-list-type:hybrid;
	mso-list-template-ids:-794890586 629604344 68485123 68485125 68485121 68485123 68485125 68485121 68485123 68485125;}
@list l12:level1
	{mso-level-number-format:bullet;
	mso-level-text:\F0F0;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:18.0pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l12:level2
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:54.0pt;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l12:level3
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:90.0pt;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l12:level4
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:126.0pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l12:level5
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:162.0pt;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l12:level6
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:198.0pt;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l12:level7
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:234.0pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l12:level8
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:270.0pt;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l12:level9
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:306.0pt;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l13
	{mso-list-id:818109750;
	mso-list-type:hybrid;
	mso-list-template-ids:856860824 68485135 68485145 68485147 68485135 68485145 68485147 68485135 68485145 68485147;}
@list l13:level1
	{mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:18.0pt;
	text-indent:-18.0pt;}
@list l13:level2
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:54.0pt;
	text-indent:-18.0pt;}
@list l13:level3
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:right;
	margin-left:90.0pt;
	text-indent:-9.0pt;}
@list l13:level4
	{mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:126.0pt;
	text-indent:-18.0pt;}
@list l13:level5
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:162.0pt;
	text-indent:-18.0pt;}
@list l13:level6
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:right;
	margin-left:198.0pt;
	text-indent:-9.0pt;}
@list l13:level7
	{mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:234.0pt;
	text-indent:-18.0pt;}
@list l13:level8
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:270.0pt;
	text-indent:-18.0pt;}
@list l13:level9
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:right;
	margin-left:306.0pt;
	text-indent:-9.0pt;}
@list l14
	{mso-list-id:855340396;
	mso-list-type:hybrid;
	mso-list-template-ids:-320860148 68485123 68485145 68485147 68485135 68485145 68485147 68485135 68485145 68485147;}
@list l14:level1
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:18.0pt;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l14:level2
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:72.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;}
@list l14:level3
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:108.0pt;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
@list l14:level5
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:180.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;}
@list l14:level6
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:216.0pt;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
@list l14:level8
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:288.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;}
@list l14:level9
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:324.0pt;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
@list l15
	{mso-list-id:866722570;
	mso-list-type:hybrid;
	mso-list-template-ids:-104716978 -854940660 68485123 68485125 68485121 68485123 68485125 68485121 68485123 68485125;}
@list l15:level1
	{mso-level-number-format:bullet;
	mso-level-text:\F071;
	mso-level-tab-stop:53.5pt;
	mso-level-number-position:left;
	margin-left:53.5pt;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l15:level2
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:72.9pt;
	mso-level-number-position:left;
	margin-left:72.9pt;
	text-indent:-18.0pt;
	font-family:"Courier New";
	mso-bidi-font-family:"Times New Roman";}
@list l15:level3
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:108.9pt;
	mso-level-number-position:left;
	margin-left:108.9pt;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l15:level4
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:144.9pt;
	mso-level-number-position:left;
	margin-left:144.9pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l15:level5
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:180.9pt;
	mso-level-number-position:left;
	margin-left:180.9pt;
	text-indent:-18.0pt;
	font-family:"Courier New";
	mso-bidi-font-family:"Times New Roman";}
@list l15:level6
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:216.9pt;
	mso-level-number-position:left;
	margin-left:216.9pt;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l15:level7
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:252.9pt;
	mso-level-number-position:left;
	margin-left:252.9pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l15:level8
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:288.9pt;
	mso-level-number-position:left;
	margin-left:288.9pt;
	text-indent:-18.0pt;
	font-family:"Courier New";
	mso-bidi-font-family:"Times New Roman";}
@list l15:level9
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:324.9pt;
	mso-level-number-position:left;
	margin-left:324.9pt;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l16
	{mso-list-id:899484366;
	mso-list-type:hybrid;
	mso-list-template-ids:1382607296 629604344 68485123 68485125 68485121 68485123 68485125 68485121 68485123 68485125;}
@list l16:level1
	{mso-level-number-format:bullet;
	mso-level-text:\F0F0;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l16:level2
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l16:level3
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l16:level4
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l16:level5
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l16:level6
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l16:level7
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l16:level8
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l16:level9
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l17
	{mso-list-id:900748180;
	mso-list-type:hybrid;
	mso-list-template-ids:1123681358 68485123 68485123 68485125 68485121 68485123 68485125 68485121 68485123 68485125;}
@list l17:level1
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:18.0pt;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l17:level2
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l17:level3
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l17:level4
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l17:level5
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l17:level6
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l17:level7
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l17:level8
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l17:level9
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l18
	{mso-list-id:918293880;
	mso-list-type:hybrid;
	mso-list-template-ids:-1356416794 68485123 68485123 68485125 68485121 68485123 68485125 68485121 68485123 68485125;}
@list l18:level1
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:18.0pt;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l18:level2
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l18:level3
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l18:level4
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l18:level5
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l18:level6
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l18:level7
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l18:level8
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l18:level9
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l19
	{mso-list-id:934510015;
	mso-list-type:hybrid;
	mso-list-template-ids:-851394306 68485121 68485123 68485125 68485121 68485123 68485125 68485121 68485123 68485125;}
@list l19:level1
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l19:level2
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l19:level3
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l19:level4
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l19:level5
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l19:level6
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l19:level7
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l19:level8
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l19:level9
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l20
	{mso-list-id:1130900592;
	mso-list-type:hybrid;
	mso-list-template-ids:68716354 68485121 68485123 68485125 68485121 68485123 68485125 68485121 68485123 68485125;}
@list l20:level1
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l20:level2
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l20:level3
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l20:level4
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l20:level5
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l20:level6
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l20:level7
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l20:level8
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l20:level9
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l21
	{mso-list-id:1168525192;
	mso-list-type:hybrid;
	mso-list-template-ids:-1118657810 68485121 68485123 68485125 68485121 68485123 68485125 68485121 68485123 68485125;}
@list l21:level1
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l21:level2
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l21:level3
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l21:level4
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l21:level5
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l21:level6
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l21:level7
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l21:level8
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l21:level9
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l22
	{mso-list-id:1172456069;
	mso-list-template-ids:1321470070;}
@list l22:level1
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:36.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Symbol;}
@list l22:level2
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:72.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:"Courier New";
	mso-bidi-font-family:"Times New Roman";}
@list l22:level3
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:108.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l22:level4
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:144.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l22:level5
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:180.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l22:level6
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:216.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l22:level7
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:252.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l22:level8
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:288.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l22:level9
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:324.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l23
	{mso-list-id:1201165151;
	mso-list-type:hybrid;
	mso-list-template-ids:196139508 68485135 68485145 68485147 68485135 68485145 68485147 68485135 68485145 68485147;}
@list l23:level1
	{mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:18.0pt;
	text-indent:-18.0pt;}
@list l23:level2
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:54.0pt;
	text-indent:-18.0pt;}
@list l23:level3
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:right;
	margin-left:90.0pt;
	text-indent:-9.0pt;}
@list l23:level4
	{mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:126.0pt;
	text-indent:-18.0pt;}
@list l23:level5
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:162.0pt;
	text-indent:-18.0pt;}
@list l23:level6
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:right;
	margin-left:198.0pt;
	text-indent:-9.0pt;}
@list l23:level7
	{mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:234.0pt;
	text-indent:-18.0pt;}
@list l23:level8
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:270.0pt;
	text-indent:-18.0pt;}
@list l23:level9
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:right;
	margin-left:306.0pt;
	text-indent:-9.0pt;}
@list l24
	{mso-list-id:1363286667;
	mso-list-template-ids:-733840872;}
@list l24:level1
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:36.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Symbol;}
@list l24:level2
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:72.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:"Courier New";
	mso-bidi-font-family:"Times New Roman";}
@list l24:level3
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:108.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l24:level4
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:144.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l24:level5
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:180.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l24:level6
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:216.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l24:level7
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:252.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l24:level8
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:288.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l24:level9
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:324.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l25
	{mso-list-id:1396659143;
	mso-list-type:hybrid;
	mso-list-template-ids:469799150 68485135 68485145 68485147 68485135 68485145 68485147 68485135 68485145 68485147;}
@list l25:level1
	{mso-level-tab-stop:36.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;}
@list l25:level2
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:72.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;}
@list l25:level3
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:108.0pt;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
@list l25:level5
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:180.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;}
@list l25:level6
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:216.0pt;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
@list l25:level8
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:288.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;}
@list l25:level9
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:324.0pt;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
@list l26
	{mso-list-id:1412238189;
	mso-list-type:hybrid;
	mso-list-template-ids:-1040033820 573856250 68485145 68485147 68485135 68485145 68485147 68485135 68485145 68485147;}
@list l26:level1
	{mso-level-start-at:2;
	mso-level-tab-stop:36.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:"Times New Roman","serif";}
@list l26:level2
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:72.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;}
@list l26:level3
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:108.0pt;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
@list l26:level5
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:180.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;}
@list l26:level6
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:216.0pt;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
@list l26:level8
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:288.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;}
@list l26:level9
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:324.0pt;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
@list l27
	{mso-list-id:1413359509;
	mso-list-type:hybrid;
	mso-list-template-ids:-1002253240 -1344234584 68485145 68485147 68485135 68485145 68485147 68485135 68485145 68485147;}
@list l27:level1
	{mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:18.0pt;
	text-indent:-18.0pt;
	mso-ansi-font-weight:normal;}
@list l27:level2
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:54.0pt;
	text-indent:-18.0pt;}
@list l27:level3
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:right;
	margin-left:90.0pt;
	text-indent:-9.0pt;}
@list l27:level4
	{mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:126.0pt;
	text-indent:-18.0pt;}
@list l27:level5
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:162.0pt;
	text-indent:-18.0pt;}
@list l27:level6
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:right;
	margin-left:198.0pt;
	text-indent:-9.0pt;}
@list l27:level7
	{mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:234.0pt;
	text-indent:-18.0pt;}
@list l27:level8
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:270.0pt;
	text-indent:-18.0pt;}
@list l27:level9
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:right;
	margin-left:306.0pt;
	text-indent:-9.0pt;}
@list l28
	{mso-list-id:1609435512;
	mso-list-type:hybrid;
	mso-list-template-ids:-705164358 68485123 68485123 68485125 68485121 68485123 68485125 68485121 68485123 68485125;}
@list l28:level1
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:18.0pt;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l28:level2
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:54.0pt;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l28:level3
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:90.0pt;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l28:level4
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:126.0pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l28:level5
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:162.0pt;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l28:level6
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:198.0pt;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l28:level7
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:234.0pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l28:level8
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:270.0pt;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l28:level9
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:306.0pt;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l29
	{mso-list-id:1637564385;
	mso-list-type:hybrid;
	mso-list-template-ids:-597784330 68485121 68485123 68485125 68485121 68485123 68485125 68485121 68485123 68485125;}
@list l29:level1
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l29:level2
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l29:level3
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l29:level4
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l29:level5
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l29:level6
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l29:level7
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l29:level8
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l29:level9
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l30
	{mso-list-id:1655529241;
	mso-list-template-ids:885684094;}
@list l30:level1
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:36.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Symbol;}
@list l30:level2
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:72.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:"Courier New";
	mso-bidi-font-family:"Times New Roman";}
@list l30:level3
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:108.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l30:level4
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:144.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l30:level5
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:180.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l30:level6
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:216.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l30:level7
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:252.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l30:level8
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:288.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l30:level9
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:324.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l31
	{mso-list-id:1801262320;
	mso-list-type:hybrid;
	mso-list-template-ids:2060375584 42497550 68485145 68485147 68485135 68485145 68485147 68485135 68485145 68485147;}
@list l31:level1
	{mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:18.0pt;
	text-indent:-18.0pt;
	mso-ansi-font-weight:bold;}
@list l31:level2
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:54.0pt;
	text-indent:-18.0pt;}
@list l31:level3
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:right;
	margin-left:90.0pt;
	text-indent:-9.0pt;}
@list l31:level4
	{mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:126.0pt;
	text-indent:-18.0pt;}
@list l31:level5
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:162.0pt;
	text-indent:-18.0pt;}
@list l31:level6
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:right;
	margin-left:198.0pt;
	text-indent:-9.0pt;}
@list l31:level7
	{mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:234.0pt;
	text-indent:-18.0pt;}
@list l31:level8
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:270.0pt;
	text-indent:-18.0pt;}
@list l31:level9
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:right;
	margin-left:306.0pt;
	text-indent:-9.0pt;}
@list l32
	{mso-list-id:1826435015;
	mso-list-type:hybrid;
	mso-list-template-ids:1755093740 629604344 68485123 68485125 68485121 68485123 68485125 68485121 68485123 68485125;}
@list l32:level1
	{mso-level-number-format:bullet;
	mso-level-text:\F0F0;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:18.0pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l32:level2
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:54.0pt;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l32:level3
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:90.0pt;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l32:level4
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:126.0pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l32:level5
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:162.0pt;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l32:level6
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:198.0pt;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l32:level7
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:234.0pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l32:level8
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:270.0pt;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l32:level9
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:306.0pt;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l33
	{mso-list-id:1890067101;
	mso-list-type:hybrid;
	mso-list-template-ids:955545206 629604344 68485123 68485125 68485121 68485123 68485125 68485121 68485123 68485125;}
@list l33:level1
	{mso-level-number-format:bullet;
	mso-level-text:\F0F0;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:18.0pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l33:level2
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:54.0pt;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l33:level3
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:90.0pt;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l33:level4
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:126.0pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l33:level5
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:162.0pt;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l33:level6
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:198.0pt;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l33:level7
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:234.0pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l33:level8
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:270.0pt;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l33:level9
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:306.0pt;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l34
	{mso-list-id:1980070903;
	mso-list-template-ids:-159075346;}
@list l34:level1
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:36.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Symbol;}
@list l34:level2
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:72.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:"Courier New";
	mso-bidi-font-family:"Times New Roman";}
@list l34:level3
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:108.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l34:level4
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:144.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l34:level5
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:180.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l34:level6
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:216.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l34:level7
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:252.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l34:level8
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:288.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l34:level9
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:324.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l35
	{mso-list-id:2025400934;
	mso-list-type:hybrid;
	mso-list-template-ids:711859578 1216785924 68485145 68485147 68485135 68485145 68485147 68485135 68485145 68485147;}
@list l35:level1
	{mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:18.0pt;
	text-indent:-18.0pt;
	mso-ansi-font-weight:normal;}
@list l35:level2
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:54.0pt;
	text-indent:-18.0pt;}
@list l35:level3
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:right;
	margin-left:90.0pt;
	text-indent:-9.0pt;}
@list l35:level4
	{mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:126.0pt;
	text-indent:-18.0pt;}
@list l35:level5
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:162.0pt;
	text-indent:-18.0pt;}
@list l35:level6
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:right;
	margin-left:198.0pt;
	text-indent:-9.0pt;}
@list l35:level7
	{mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:234.0pt;
	text-indent:-18.0pt;}
@list l35:level8
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:270.0pt;
	text-indent:-18.0pt;}
@list l35:level9
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:right;
	margin-left:306.0pt;
	text-indent:-9.0pt;}
@list l36
	{mso-list-id:2104914762;
	mso-list-template-ids:-2122134022;}
@list l36:level1
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:36.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Symbol;}
@list l36:level2
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:72.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:"Courier New";
	mso-bidi-font-family:"Times New Roman";}
@list l36:level3
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:108.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l36:level4
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:144.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l36:level5
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:180.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l36:level6
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:216.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l36:level7
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:252.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l36:level8
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:288.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
@list l36:level9
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:324.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	mso-ansi-font-size:10.0pt;
	font-family:Wingdings;}
ol
	{margin-bottom:0cm;}
ul
	{margin-bottom:0cm;}
-->
</style>
<!--[if gte mso 10]>
<style>
 /* Style Definitions */
 table.MsoNormalTable
	{mso-style-name:Standardowy;
	mso-tstyle-rowband-size:0;
	mso-tstyle-colband-size:0;
	mso-style-noshow:yes;
	mso-style-priority:99;
	mso-style-parent:"";
	mso-padding-alt:0cm 5.4pt 0cm 5.4pt;
	mso-para-margin-top:0cm;
	mso-para-margin-right:0cm;
	mso-para-margin-bottom:10.0pt;
	mso-para-margin-left:0cm;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-fareast-language:EN-US;}
table.MsoTableGrid
	{mso-style-name:"Tabela - Siatka";
	mso-tstyle-rowband-size:0;
	mso-tstyle-colband-size:0;
	mso-style-priority:59;
	mso-style-unhide:no;
	border:solid windowtext 1.0pt;
	mso-border-alt:solid windowtext .5pt;
	mso-padding-alt:0cm 5.4pt 0cm 5.4pt;
	mso-border-insideh:.5pt solid windowtext;
	mso-border-insidev:.5pt solid windowtext;
	mso-para-margin:0cm;
	mso-para-margin-bottom:.0001pt;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-fareast-language:EN-US;}
</style>
<![endif]--><!--[if gte mso 9]><xml>
 <o:shapedefaults v:ext="edit" spidmax="1026"/>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <o:shapelayout v:ext="edit">
  <o:idmap v:ext="edit" data="1"/>
 </o:shapelayout></xml><![endif]-->
</head>

<body lang=PL style='tab-interval:35.4pt'>
<form action="graWKarty.php">
<div class=WordSection1>

<div style='mso-element:para-border-div;border-top:solid windowtext 1.0pt;
border-left:none;border-bottom:solid windowtext 1.0pt;border-right:none;
mso-border-top-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;
padding:1.0pt 0cm 1.0pt 0cm;background:#C6D9F1;mso-background-themecolor:text2;
mso-background-themetint:51'>
<br>
<p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
text-align:center;background:#C6D9F1;mso-background-themecolor:text2;
mso-background-themetint:51;border:none;mso-border-top-alt:solid windowtext .5pt;
mso-border-bottom-alt:solid windowtext .5pt;padding:0cm;mso-padding-alt:1.0pt 0cm 1.0pt 0cm'><b><span
style='mso-bidi-font-family:Arial'>Dane <span class=SpellE>socjo</span>-demograficzne</span></b><b
style='mso-bidi-font-weight:normal'><o:p></o:p></b></p>
<br>
</div>

<p class=MsoListParagraphCxSpFirst style='margin-left:18.0pt;mso-add-space:
auto;text-indent:-18.0pt;mso-list:l1 level1 lfo1'><![if !supportLists]><b><span
style='mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin'><span
style='mso-list:Ignore'>1.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span></span></b><![endif]><b><span style='mso-bidi-font-family:Arial'>Ile
ma Pan/Pani lat?<input type="number" name="SD1" min="1" max="999"><o:p></o:p></span></b></p>
<br>
<p class=MsoListParagraphCxSpMiddle style='margin-top:0cm;margin-right:0cm;
margin-bottom:0cm;margin-left:18.0pt;margin-bottom:.0001pt;mso-add-space:auto;
text-indent:-18.0pt;line-height:normal;mso-list:l1 level1 lfo1;mso-layout-grid-align:
none;text-autospace:none'><![if !supportLists]><b><span style='mso-bidi-font-family:
Calibri;mso-bidi-theme-font:minor-latin'><span style='mso-list:Ignore'>2.<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span></b><![endif]><b><span
style='mso-bidi-font-family:Arial'>Prosz� zaznaczy� swoj� p�e�: </span></b><span
style='mso-bidi-font-family:Arial;mso-bidi-font-weight:bold'> <br> <input type="radio" name="SD2" value="1" checked> M�czyzna<br>
  <input type="radio" name="SD2" value="2"> Kobieta<br><b><o:p></o:p></b></span></p>
<br>
<p class=MsoListParagraphCxSpMiddle style='margin-top:0cm;margin-right:0cm;
margin-bottom:0cm;margin-left:18.0pt;margin-bottom:.0001pt;mso-add-space:auto;
text-indent:-18.0pt;line-height:normal;mso-list:l1 level1 lfo1;mso-layout-grid-align:
none;text-autospace:none'><![if !supportLists]><b><span style='mso-bidi-font-family:
Calibri;mso-bidi-theme-font:minor-latin'><span style='mso-list:Ignore'>3.<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span></b><![endif]><b
style='mso-bidi-font-weight:normal'>Prosz� wpisa� sum� uko�czonych lat nauki</b>
(np. podstaw�wka 6, gimnazjum 3, liceum 3, studia � 3:  suma: 15lat)<span
style='mso-bidi-font-family:Arial'> <input type="number" name="SD3" min="1" max="999"> <b><o:p></o:p></b></span></p>
<br>
<p class=MsoListParagraphCxSpLast style='margin-top:0cm;margin-right:0cm;
margin-bottom:0cm;margin-left:18.0pt;margin-bottom:.0001pt;mso-add-space:auto;
text-indent:-18.0pt;line-height:normal;mso-list:l1 level1 lfo1;mso-layout-grid-align:
none;text-autospace:none'><![if !supportLists]><b><span style='mso-bidi-font-family:
Calibri;mso-bidi-theme-font:minor-latin'><span style='mso-list:Ignore'>4.<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span></b><![endif]><b><span
style='mso-bidi-font-family:Arial'>Jaka jest Pani/Pana sytuacja zawodowa
AKTUALNA?<o:p></o:p></span></b></p>

<p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
normal;mso-layout-grid-align:none;text-autospace:none'><span lang=FR
style='mso-bidi-font-family:Arial;mso-ansi-language:FR'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Mo�liwe kilka
odpowiedzi <o:p></o:p></span></p>


<!---<input type="hidden" name="SD4" value="W">----->

<p class=MsoListParagraphCxSpFirst style='margin-top:0cm;margin-right:0cm;
margin-bottom:0cm;margin-left:18.0pt;margin-bottom:.0001pt;mso-add-space:auto;
text-indent:-18.0pt;line-height:normal;mso-list:l28 level1 lfo28;mso-layout-grid-align:
none;text-autospace:none'><![if !supportLists]><span lang=FR style='font-family:
"Courier New";mso-fareast-font-family:"Courier New";mso-ansi-language:FR'><span
style='mso-list:Ignore'><span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;
</span></span></span><![endif]><span lang=FR style='mso-bidi-font-family:Arial;
mso-ansi-language:FR'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" name="praca1" value="1"> Osoba studiuj�ca <o:p></o:p></span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-top:0cm;margin-right:0cm;
margin-bottom:0cm;margin-left:18.0pt;margin-bottom:.0001pt;mso-add-space:auto;
text-indent:-18.0pt;line-height:normal;mso-list:l28 level1 lfo28;mso-layout-grid-align:
none;text-autospace:none'><![if !supportLists]><span lang=FR style='font-family:
"Courier New";mso-fareast-font-family:"Courier New";mso-ansi-language:FR'><span
style='mso-list:Ignore'><span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;
</span></span></span><![endif]><span lang=FR style='mso-bidi-font-family:Arial;
mso-ansi-language:FR'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" name="praca1" value="2"> Osoba zatrudniona<o:p></o:p></span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-top:0cm;margin-right:0cm;
margin-bottom:0cm;margin-left:18.0pt;margin-bottom:.0001pt;mso-add-space:auto;
text-indent:-18.0pt;line-height:normal;mso-list:l28 level1 lfo28;mso-layout-grid-align:
none;text-autospace:none'><![if !supportLists]><span lang=FR style='font-family:
"Courier New";mso-fareast-font-family:"Courier New";mso-ansi-language:FR'><span
style='mso-list:Ignore'><span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;
</span></span></span><![endif]><span lang=FR style='mso-bidi-font-family:Arial;
mso-ansi-language:FR'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" name="praca1" value="3"> Osoba bezrobotna<o:p></o:p></span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-top:0cm;margin-right:0cm;
margin-bottom:0cm;margin-left:18.0pt;margin-bottom:.0001pt;mso-add-space:auto;
text-indent:-18.0pt;line-height:normal;mso-list:l28 level1 lfo28;mso-layout-grid-align:
none;text-autospace:none'><![if !supportLists]><span lang=FR style='font-family:
"Courier New";mso-fareast-font-family:"Courier New";mso-ansi-language:FR'><span
style='mso-list:Ignore'><span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;
</span></span></span><![endif]><span lang=FR style='mso-bidi-font-family:Arial;
mso-ansi-language:FR'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" name="praca1" value="4"> Osoba na rencie inwalidzkiej<o:p></o:p></span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-top:0cm;margin-right:0cm;
margin-bottom:0cm;margin-left:18.0pt;margin-bottom:.0001pt;mso-add-space:auto;
text-indent:-18.0pt;line-height:normal;mso-list:l28 level1 lfo28;mso-layout-grid-align:
none;text-autospace:none'><![if !supportLists]><span lang=FR style='font-family:
"Courier New";mso-fareast-font-family:"Courier New";mso-ansi-language:FR'><span
style='mso-list:Ignore'><span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;
</span></span></span><![endif]><span lang=FR style='mso-bidi-font-family:Arial;
mso-ansi-language:FR'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" name="praca1" value="5"> Korzystam z pomocy socjalnej<o:p></o:p></span></p>

<p class=MsoListParagraphCxSpLast style='margin-top:0cm;margin-right:0cm;
margin-bottom:0cm;margin-left:18.0pt;margin-bottom:.0001pt;mso-add-space:auto;
text-indent:-18.0pt;line-height:normal;mso-list:l28 level1 lfo28;mso-layout-grid-align:
none;text-autospace:none'><![if !supportLists]><span lang=FR style='font-family:
"Courier New";mso-fareast-font-family:"Courier New";mso-ansi-language:FR'><span
style='mso-list:Ignore'><span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;
</span></span></span><![endif]><span style='mso-bidi-font-family:Arial'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Inne<input type="text" name="praca1"></span><span
lang=FR style='mso-bidi-font-family:Arial;mso-ansi-language:FR'><o:p></o:p></span></p>
<br>
<div style='mso-element:para-border-div;border-top:solid windowtext 1.0pt;
border-left:none;border-bottom:solid windowtext 1.0pt;border-right:none;
mso-border-top-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;
padding:1.0pt 0cm 1.0pt 0cm;background:#C6D9F1;mso-background-themecolor:text2;
mso-background-themetint:51'>

<p class=MsoNormal align=center style='margin-top:12.0pt;margin-right:0cm;
margin-bottom:0cm;margin-left:0cm;margin-bottom:.0001pt;text-align:center;
line-height:normal;background:#C6D9F1;mso-background-themecolor:text2;
mso-background-themetint:51;mso-layout-grid-align:none;text-autospace:none;
border:none;mso-border-top-alt:solid windowtext .5pt;mso-border-bottom-alt:
solid windowtext .5pt;padding:0cm;mso-padding-alt:1.0pt 0cm 1.0pt 0cm'><b><span
style='mso-bidi-font-family:Arial'>Zdrowie i samopoczucie<o:p></o:p></span></b></p>

<br>
</div>

<p class=MsoNormal style='line-height:normal;mso-layout-grid-align:none;
text-autospace:none'><i><span style='mso-bidi-font-family:Arial'>Poni�sze
pytania odnosz� si� do Pani/Pana og�lnego stanu zdrowia. </span></i></p>

<p class=MsoListParagraphCxSpFirst style='margin-left:18.0pt;mso-add-space:
auto;text-indent:-18.0pt;mso-list:l1 level1 lfo1'><![if !supportLists]><span
class=shorttext><b style='mso-bidi-font-weight:normal'><span lang=FR
style='mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;mso-ansi-language:
FR'><span style='mso-list:Ignore'>5.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span></span></b></span><![endif]><span class=hps>Czy ma Pani/Pan
jakie� aktualne problemy zdrowotne</span><span class=shorttext>? <input type="radio" name="zdrowieISapopoczucie1" value="1" checked> TAK
   <input type="radio" name="zdrowieISapopoczucie1" value="0" checked> NIE<br></span><span
class=shorttext><span lang=FR style='mso-ansi-language:FR'><o:p></o:p></span></span></p>
<br>
<p class=MsoListParagraphCxSpMiddle style='margin-top:0cm;margin-right:0cm;
margin-bottom:0cm;margin-left:18.0pt;margin-bottom:.0001pt;mso-add-space:auto;
text-indent:-18.0pt;line-height:normal;mso-list:l1 level1 lfo1'><![if !supportLists]><b
style='mso-bidi-font-weight:normal'><span lang=FR style='mso-bidi-font-family:
Calibri;mso-bidi-theme-font:minor-latin;mso-ansi-language:FR;mso-fareast-language:
PL'><span style='mso-list:Ignore'>6.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span></span></b><![endif]><span class=hps>Czy ma Pani/Pan jakie� aktualne
problemy ze zdrowiem psychicznym</span><span class=shorttext>? <input type="radio" name="zdrowieISapopoczucie2" value="1" checked> TAK
   <input type="radio" name="zdrowieISapopoczucie2" value="0" checked> NIE<br></span><span
lang=FR style='mso-fareast-font-family:"Times New Roman";mso-bidi-font-family:
"Times New Roman";mso-ansi-language:FR;mso-fareast-language:PL'><o:p></o:p></span></p>
<br>
<p class=MsoListParagraphCxSpMiddle style='margin-left:18.0pt;mso-add-space:
auto;text-indent:-18.0pt;mso-list:l1 level1 lfo1'><![if !supportLists]><b
style='mso-bidi-font-weight:normal'><span lang=FR style='mso-bidi-font-family:
Calibri;mso-bidi-theme-font:minor-latin;mso-ansi-language:FR'><span
style='mso-list:Ignore'>7.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span></span></b><![endif]><span class=hps>Czy mia�a Pani/mia� Pan
jakie� problemy ze zdrowiem psychicznym w przesz�o�ci? </span><span
class=shorttext><span lang=FR style='mso-ansi-language:FR'><input type="radio" name="zdrowieISapopoczucie3" value="1" checked> TAK
   <input type="radio" name="zdrowieISapopoczucie3" value="0" checked> NIE<br></span></span><span
lang=FR style='mso-ansi-language:FR'><o:p></o:p></span></p>
<br>
<p class=MsoListParagraphCxSpMiddle style='margin-top:0cm;margin-right:0cm;
margin-bottom:0cm;margin-left:18.0pt;margin-bottom:.0001pt;mso-add-space:auto;
text-indent:-18.0pt;line-height:normal;mso-list:l1 level1 lfo1'><![if !supportLists]><b
style='mso-bidi-font-weight:normal'><span lang=FR style='mso-bidi-font-family:
Calibri;mso-bidi-theme-font:minor-latin;mso-ansi-language:FR;mso-fareast-language:
PL'><span style='mso-list:Ignore'>8.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span></span></b><![endif]><span class=hps>Czy osoby z najbli�szego
otoczenia wyra�aj� obawy dotycz�ce Pana/i samopoczucia psychicznego? </span><span
class=shorttext><span lang=FR style='mso-ansi-language:FR'><input type="radio" name="zdrowieISapopoczucie4" value="1" checked> TAK
   <input type="radio" name="zdrowieISapopoczucie4" value="0" checked> NIE<br></span></span><span
lang=FR style='mso-fareast-font-family:"Times New Roman";mso-bidi-font-family:
"Times New Roman";mso-ansi-language:FR;mso-fareast-language:PL'><o:p></o:p></span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-top:12.0pt;margin-right:0cm;
margin-bottom:10.0pt;margin-left:18.0pt;mso-add-space:auto;text-indent:-18.0pt;
mso-list:l1 level1 lfo1'><![if !supportLists]><span class=hps><b
style='mso-bidi-font-weight:normal'><span style='mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin'><span style='mso-list:Ignore'>9.<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span></b></span><![endif]><span
class=hps><b style='mso-bidi-font-weight:normal'>Prosz� zaznaczy� nat�enie
zm�czenia, jakie odczuwa� Pan/i w ci�gu ostatniego tygodnia (0 � brak
zm�czenia; 10 � maksymalne zm�czenie)</b> <o:p></o:p></span></p>


<!-- moje -->
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Prosz� zaznaczy� na skali: 0<input type="range" name="zdrowieISapopoczucie5" min="1" max="10" value="5" onchange="myFunction1(this.value)"> 10
<p id="demo1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Wybra� Pan/Pani 5</p>
<script>
function myFunction1(val) {
    
document.getElementById("demo1").innerHTML = " &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  Wybra� Pan/Pani "+val;
}
</script>
<!-- moje -->



<p class=MsoListParagraphCxSpFirst style='margin-top:12.0pt;margin-right:0cm;
margin-bottom:10.0pt;margin-left:18.0pt;mso-add-space:auto;text-indent:-18.0pt;
mso-list:l1 level1 lfo1'><![if !supportLists]><span class=hps><b
style='mso-bidi-font-weight:normal'><span style='mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin'><span style='mso-list:Ignore'>10.<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span></span></b></span><![endif]><span
class=hps><b style='mso-bidi-font-weight:normal'>Prosz� zaznaczy� jak ocenia Pan/i swoj� sprawno�� fizyczn� w ci�gu ostatniego tygodnia (0 � brak zm�czenia;
10 � maksymalne zm�czenie) </b><o:p></o:p></span></p>

<!-- moje -->
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Prosz� zaznaczy� na skali: 0<input type="range" name="zdrowieISapopoczucie6" min="1" max="10" value="5" onchange="myFunction2(this.value)">10
<p id="demo2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Wybra� Pan/Pani 5</p>
<script>
function myFunction2(val) {
    
document.getElementById("demo2").innerHTML = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Wybra� Pan/Pani "+val;
}
</script>
<!-- moje -->



<p class=MsoListParagraphCxSpMiddle style='margin-top:12.0pt;margin-right:0cm;
margin-bottom:10.0pt;margin-left:18.0pt;mso-add-space:auto;text-indent:-18.0pt;
mso-list:l1 level1 lfo1'><![if !supportLists]><span class=hps><b
style='mso-bidi-font-weight:normal'><span style='mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin'><span style='mso-list:Ignore'>11.<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span></span></b></span><![endif]><span
class=hps><b style='mso-bidi-font-weight:normal'>Prosz� zaznaczy� nat�enie
stresu, jakie odczuwa� Pan/i w ci�gu ostatniego tygodnia (0 � brak
zm�czenia; 10 � maksymalne zm�czenie) </b><o:p></o:p></span></p>

<!-- moje -->
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Prosz� zaznaczy� na skali: 0<input type="range" name="zdrowieISapopoczucie7" min="1" max="10" value="5" onchange="myFunction3(this.value)">10
<p id="demo3">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Wybra� Pan/Pani 5</p>
<script>
function myFunction3(val) {
    
document.getElementById("demo3").innerHTML = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Wybra� Pan/Pani "+val;
}
</script>
<!-- moje -->

<p class=MsoListParagraphCxSpFirst style='margin-top:12.0pt;margin-right:0cm;
margin-bottom:10.0pt;margin-left:18.0pt;mso-add-space:auto;text-indent:-18.0pt;
line-height:normal;mso-list:l1 level1 lfo1;mso-layout-grid-align:none;
text-autospace:none'><![if !supportLists]><b style='mso-bidi-font-weight:normal'><span
style='mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin'><span
style='mso-list:Ignore'>12.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;
</span></span></span></b><![endif]><b><span style='mso-bidi-font-family:Arial'>Jakie
substancje stosowa� Pan/i w ci�gu ostatnich dw�ch miesi�cy? </span></b><span
style='mso-bidi-font-family:Arial'><o:p></o:p></span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-top:12.0pt;margin-right:0cm;
margin-bottom:10.0pt;margin-left:18.0pt;mso-add-space:auto;line-height:normal;
mso-layout-grid-align:none;text-autospace:none'><span style='mso-bidi-font-family:
Arial;mso-bidi-font-weight:bold'>Prosz� zaznaczy� wszystkie, kt�re Pana/i
dotycz�. </span><span style='mso-bidi-font-family:Arial'><o:p></o:p></span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-top:12.0pt;margin-right:0cm;
margin-bottom:0cm;margin-left:18.0pt;margin-bottom:.0001pt;mso-add-space:auto;
text-indent:-18.0pt;line-height:normal;mso-list:l14 level1 lfo29;mso-layout-grid-align:
none;text-autospace:none'><![if !supportLists]><span lang=FR style='font-family:
"Courier New";mso-fareast-font-family:"Courier New";mso-ansi-language:FR;
mso-bidi-font-weight:bold'><span style='mso-list:Ignore'>&nbsp;<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span></span><![endif]><span
lang=FR style='mso-bidi-font-family:Arial;mso-ansi-language:FR;mso-bidi-font-weight:
bold'><input type="checkbox" name="urzywka1" value=" 1"> Alkohol<o:p></o:p></span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-top:0cm;margin-right:0cm;
margin-bottom:0cm;margin-left:18.0pt;margin-bottom:.0001pt;mso-add-space:auto;
text-indent:-18.0pt;line-height:normal;mso-list:l14 level1 lfo29;mso-layout-grid-align:
none;text-autospace:none'><![if !supportLists]><span lang=FR style='font-family:
"Courier New";mso-fareast-font-family:"Courier New";mso-ansi-language:FR;
mso-bidi-font-weight:bold'><span style='mso-list:Ignore'>&nbsp;<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span></span><![endif]><span
lang=FR style='mso-bidi-font-family:Arial;mso-ansi-language:FR;mso-bidi-font-weight:
bold'><input type="checkbox" name="urzywka1" value=" 2"> Tyto�<o:p></o:p></span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-top:0cm;margin-right:0cm;
margin-bottom:0cm;margin-left:18.0pt;margin-bottom:.0001pt;mso-add-space:auto;
text-indent:-18.0pt;line-height:normal;mso-list:l14 level1 lfo29;mso-layout-grid-align:
none;text-autospace:none'><![if !supportLists]><span lang=FR style='font-family:
"Courier New";mso-fareast-font-family:"Courier New";mso-ansi-language:FR;
mso-bidi-font-weight:bold'><span style='mso-list:Ignore'>&nbsp;<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span></span><![endif]><span
lang=FR style='mso-bidi-font-family:Arial;mso-ansi-language:FR;mso-bidi-font-weight:
bold'><input type="checkbox" name="urzywka1" value=" 3"> Konopie indyjskie (mariuhuana)<o:p></o:p></span></p>

<p class=MsoListParagraphCxSpLast style='margin-top:0cm;margin-right:0cm;
margin-bottom:0cm;margin-left:18.0pt;margin-bottom:.0001pt;mso-add-space:auto;
text-indent:-18.0pt;line-height:normal;mso-list:l14 level1 lfo29;mso-layout-grid-align:
none;text-autospace:none'><![if !supportLists]><span lang=FR style='font-family:
"Courier New";mso-fareast-font-family:"Courier New";mso-ansi-language:FR'><span
style='mso-list:Ignore'>&nbsp;<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;
</span></span></span><![endif]><span lang=FR style='mso-bidi-font-family:Arial;
mso-ansi-language:FR'><input type="checkbox" name="urzywka1" value=" 4"> inne u�ywki<o:p></o:p></span></p>

<span style='font-size:11.0pt;line-height:115%;font-family:"Calibri","sans-serif";
mso-ascii-theme-font:minor-latin;mso-fareast-font-family:Calibri;mso-fareast-theme-font:
minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-font-family:Arial;
mso-ansi-language:PL;mso-fareast-language:EN-US;mso-bidi-language:AR-SA;
mso-bidi-font-weight:bold'><br clear=all style='mso-special-character:line-break;
page-break-before:always'>
</span>


<div style='mso-element:para-border-div;border-top:solid windowtext 1.0pt;
border-left:none;border-bottom:solid windowtext 1.0pt;border-right:none;
mso-border-top-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;
padding:1.0pt 0cm 1.0pt 0cm;background:#C6D9F1;mso-background-themecolor:text2;
mso-background-themetint:51'>

<p class=MsoNormal align=center style='margin-top:12.0pt;margin-right:0cm;
margin-bottom:0cm;margin-left:0cm;margin-bottom:.0001pt;text-align:center;
background:#C6D9F1;mso-background-themecolor:text2;mso-background-themetint:
51;border:none;mso-border-top-alt:solid windowtext .5pt;mso-border-bottom-alt:
solid windowtext .5pt;padding:0cm;mso-padding-alt:1.0pt 0cm 1.0pt 0cm'><b><span
style='mso-bidi-font-family:Arial'>Gry internetowe<o:p></o:p></span></b></p>
<br>

</div>

<p class=MsoListParagraphCxSpFirst style='margin-left:18.0pt;mso-add-space:
auto;text-indent:-18.0pt;mso-list:l1 level1 lfo1'><![if !supportLists]><span
class=hps><b style='mso-bidi-font-weight:normal'><span lang=FR
style='mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;mso-ansi-language:
FR'><span style='mso-list:Ignore'>13.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;
</span></span></span></b></span><![endif]><span class=hps><b style='mso-bidi-font-weight:
normal'>Czy w ci�gu ostatniego tygodnia gra� Pan/i w World of <span
class=SpellE>Warcraft</span>?   <input type="radio" name="gryInternetowe1a" value="1" checked> Tak
  <input type="radio" name="gryInternetowe1a" value="0"> Nie<br></b></span><span class=hps><span
style='mso-ansi-language:FR'> <b style='mso-bidi-font-weight:normal'><span
lang=FR><o:p></o:p></span></b></span></span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-top:12.0pt;margin-right:0cm;
margin-bottom:10.0pt;margin-left:18.0pt;mso-add-space:auto;text-indent:17.4pt'><span
class=hps>Je�li tak:<b style='mso-bidi-font-weight:normal'> Od kiedy gra Pan/i
w World of <span class=SpellE>Warcraft</span>? </b></span> 
<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="gryInternetowe1b" value="0" checked> mniej ni� p� roku<br>
&nbsp;&nbsp;&nbsp;&nbsp; <input type="radio" name="gryInternetowe1b" value="1" checked> 1 rok<br>
 &nbsp;&nbsp;&nbsp;&nbsp; <input type="radio" name="gryInternetowe1b" value="2"> 1-2 lat<br>
 &nbsp;&nbsp;&nbsp;&nbsp; <input type="radio" name="gryInternetowe1b" value="3"> 2-3 lat<br>
 &nbsp;&nbsp;&nbsp;&nbsp; <input type="radio" name="gryInternetowe1b" value="4"> 3-5 lat<br>
 &nbsp;&nbsp;&nbsp;&nbsp; <input type="radio" name="gryInternetowe1b" value="5"> >5 lat<br>

<b
style='mso-bidi-font-weight:normal'><o:p></o:p></b></span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-left:18.0pt;mso-add-space:
auto;text-indent:-18.0pt;mso-list:l1 level1 lfo1'><![if !supportLists]><span
class=hps><b style='mso-bidi-font-weight:normal'><span lang=FR
style='mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;mso-ansi-language:
FR'><span style='mso-list:Ignore'>14.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;
</span></span></span></b></span><![endif]><span class=hps><b style='mso-bidi-font-weight:
normal'>Czy w ci�gu ostatniego tygodnia gra� Pan/i w <span class=SpellE>Minecfraft</span>
?   <input type="radio" name="gryInternetowe2a" value="1" checked> Tak
  <input type="radio" name="gryInternetowe2a" value="0"> Nie<br></b></span><span class=hps><span style='mso-ansi-language:FR'> <b
style='mso-bidi-font-weight:normal'><span lang=FR><o:p></o:p></span></b></span></span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-top:12.0pt;margin-right:0cm;
margin-bottom:10.0pt;margin-left:18.0pt;mso-add-space:auto;text-indent:17.4pt'><span
class=hps>Je�li tak:<b style='mso-bidi-font-weight:normal'> Od kiedy gra Pan/i
w <span class=SpellE>Minecraft</span>? </b></span><span lang=FR
style='mso-ansi-language:FR'>
<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="gryInternetowe2b" value="0" checked> mniej ni� p� roku<br>
&nbsp;&nbsp;&nbsp;&nbsp; <input type="radio" name="gryInternetowe2b" value="1" checked> 1 rok<br>
 &nbsp;&nbsp;&nbsp;&nbsp; <input type="radio" name="gryInternetowe2b" value="2"> 1-2 lat<br>
 &nbsp;&nbsp;&nbsp;&nbsp; <input type="radio" name="gryInternetowe2b" value="3"> 2-3 lat<br>
 &nbsp;&nbsp;&nbsp;&nbsp; <input type="radio" name="gryInternetowe2b" value="4"> 3-5 lat<br>
 &nbsp;&nbsp;&nbsp;&nbsp; <input type="radio" name="gryInternetowe2b" value="5"> >5 lat<br>
<span class=hps><b style='mso-bidi-font-weight:
normal'><o:p></o:p></b></span></span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-left:18.0pt;mso-add-space:
auto;text-indent:-18.0pt;mso-list:l1 level1 lfo1'><![if !supportLists]><span
class=hps><b style='mso-bidi-font-weight:normal'><span style='mso-bidi-font-family:
Calibri;mso-bidi-theme-font:minor-latin'><span style='mso-list:Ignore'>15.<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span></span></b></span><![endif]><span
class=hps><b style='mso-bidi-font-weight:normal'>Czy w ci�gu ostatniego
tygodnia gra� Pan/i w inne gry internetowe?  <input type="radio" name="gryInternetowe3a" value="1" checked> Tak
  <input type="radio" name="gryInternetowe3a" value="0"> Nie<br></b> <b style='mso-bidi-font-weight:
normal'><o:p></o:p></b></span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-top:12.0pt;margin-right:0cm;
margin-bottom:10.0pt;margin-left:18.0pt;mso-add-space:auto;text-indent:17.4pt'><span
class=hps>Je�li tak:<b style='mso-bidi-font-weight:normal'> Prosz� poda� g��wn�
(ulubion�) gr� </b></span><input type="text" value="test" name="gryInternetowe4a"><b style='mso-bidi-font-weight:normal'><o:p></o:p></b></p>

<p class=MsoListParagraphCxSpMiddle style='margin-top:12.0pt;margin-right:0cm;
margin-bottom:10.0pt;margin-left:18.0pt;mso-add-space:auto;text-indent:-18.0pt;
mso-list:l1 level1 lfo1'><![if !supportLists]><b style='mso-bidi-font-weight:
normal'><span style='mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin'><span
style='mso-list:Ignore'>16.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;
</span></span></span></b><![endif]><span class=hps><b style='mso-bidi-font-weight:
normal'>W ci�gu ostatniego miesi�ca w jak� gr� internetow� gra� Pan/i
najcz�ciej&nbsp;? </b></span><input type="text" value="1" name="gryInternetowe5a"><b style='mso-bidi-font-weight:normal'><o:p></o:p></b></p>

<p class=MsoListParagraphCxSpMiddle style='margin-top:12.0pt;margin-right:0cm;
margin-bottom:10.0pt;margin-left:18.0pt;mso-add-space:auto;text-indent:-18.0pt;
mso-list:l1 level1 lfo1'><![if !supportLists]><span class=hps><b
style='mso-bidi-font-weight:normal'><span lang=FR style='mso-bidi-font-family:
Calibri;mso-bidi-theme-font:minor-latin;mso-ansi-language:FR'><span
style='mso-list:Ignore'>17.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;
</span></span></span></b></span><![endif]><span class=hps><b style='mso-bidi-font-weight:
normal'>Od jak dawna gra Pan/i w swoj� ulubion� gr�? </b></span><span
class=hps><span lang=FR style='mso-ansi-language:FR'><br>
<input type="radio" name="gryInternetowe6a" value="0" checked> mniej ni� p� roku<br>
  <input type="radio" name="gryInternetowe6a" value="1" checked> 1rok<br>
  <input type="radio" name="gryInternetowe6a" value="2"> 1-2lat<br>
  <input type="radio" name="gryInternetowe6a" value="3"> 2-3lat<br>
  <input type="radio" name="gryInternetowe6a" value="4"> 3-5lat<br>
 <input type="radio" name="gryInternetowe6b" value="5"> >5 lat<br>
  </span></span><span class=hps><b style='mso-bidi-font-weight:normal'><span
lang=FR style='mso-ansi-language:FR'><o:p></o:p></span></b></span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-top:12.0pt;margin-right:0cm;
margin-bottom:10.0pt;margin-left:18.0pt;mso-add-space:auto;text-indent:-18.0pt;
mso-list:l1 level1 lfo1'><![if !supportLists]><b style='mso-bidi-font-weight:
normal'><span lang=FR style='mso-bidi-font-family:Calibri;mso-bidi-theme-font:
minor-latin;mso-ansi-language:FR'><span style='mso-list:Ignore'>18.<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span></span></b><![endif]><span
class=hps><b style='mso-bidi-font-weight:normal'>W ci�gu ostatniego miesi�ca
�rednio ile dni w tygodniu gra� Pan/Pani w swoj� ulubion� gr� online? </b></span><span
lang=FR style='mso-ansi-language:FR'><input type="number" name="gryInternetowe7a" min="0" max="7"><b style='mso-bidi-font-weight:normal'><o:p></o:p></b></span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-top:12.0pt;margin-right:0cm;
margin-bottom:10.0pt;margin-left:18.0pt;mso-add-space:auto;text-indent:-18.0pt;
mso-list:l1 level1 lfo1'><![if !supportLists]><span class=hps><b
style='mso-bidi-font-weight:normal'><span lang=FR style='mso-bidi-font-family:
Calibri;mso-bidi-theme-font:minor-latin;mso-ansi-language:FR'><span
style='mso-list:Ignore'>19.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;
</span></span></span></b></span><![endif]><span class=hps><b style='mso-bidi-font-weight:
normal'>W ci�gu ostatniego miesi�ca w tych dniach, w kt�rych gra� Pan/Pani w
gry online, �rednio ile godzin dziennie zajmowa�a Panu/i ta aktywno��?
&nbsp;<input type="number" name="gryInternetowe8a" min="0" max="24"></b></span><span class=hps><b style='mso-bidi-font-weight:normal'><span
lang=FR style='mso-ansi-language:FR'><o:p></o:p></span></b></span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-top:12.0pt;margin-right:0cm;
margin-bottom:10.0pt;margin-left:18.0pt;mso-add-space:auto;text-indent:-18.0pt;
mso-list:l1 level1 lfo1'><![if !supportLists]><span class=hps><b
style='mso-bidi-font-weight:normal'><span lang=FR style='font-size:10.5pt;
mso-bidi-font-size:11.0pt;line-height:115%;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;mso-ansi-language:FR'><span style='mso-list:
Ignore'>20.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span></span></b></span><![endif]><span
class=hps><b style='mso-bidi-font-weight:normal'>Od jak dawna gra Pan/Pani z
tak� cz�stotliwo�ci�? </b></span><span style='mso-bidi-font-size:12.0pt;
line-height:115%;mso-bidi-font-family:Helvetica'><br>
<input type="radio" name="gryInternetowe99a" value="0" checked> mniej ni� p� roku<br>
  <input type="radio" name="gryInternetowe99a" value="1" checked> 1rok<br>
  <input type="radio" name="gryInternetowe99a" value="2"> 1-2lat<br>
  <input type="radio" name="gryInternetowe99a" value="3"> 2-3lat<br>
  <input type="radio" name="gryInternetowe99a" value="4"> 3-5lat<br></span>
   <input type="radio" name="gryInternetowe99b" value="5"> >5 lat<br>
  
  
  <span
class=hps><b style='mso-bidi-font-weight:normal'><span lang=FR
style='font-size:10.5pt;mso-bidi-font-size:11.0pt;line-height:115%;mso-ansi-language:
FR'><o:p></o:p></span></b></span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-top:12.0pt;margin-right:0cm;
margin-bottom:10.0pt;margin-left:18.0pt;mso-add-space:auto;text-indent:-18.0pt;
mso-list:l1 level1 lfo1'><![if !supportLists]><span class=hps><b
style='mso-bidi-font-weight:normal'><span lang=FR style='mso-bidi-font-family:
Calibri;mso-bidi-theme-font:minor-latin;mso-ansi-language:FR'><span
style='mso-list:Ignore'>21.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;
</span></span></span></b></span><![endif]><span class=hps><b style='mso-bidi-font-weight:
normal'>W ci�gu ostatnich dwunastu miesi�cy� </b></span><span class=hps><b
style='mso-bidi-font-weight:normal'><span lang=FR style='mso-ansi-language:
FR'><o:p></o:p></span></b></span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-top:12.0pt;margin-right:0cm;
margin-bottom:0cm;margin-left:54.0pt;margin-bottom:.0001pt;mso-add-space:auto;
text-indent:-18.0pt;line-height:normal;mso-list:l1 level2 lfo1;mso-layout-grid-align:
none;text-autospace:none'><![if !supportLists]><span class=hps><b
style='mso-bidi-font-weight:normal'><span style='mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin'><span style='mso-list:Ignore'>a.<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span></b></span><![endif]><span
class=hps><b style='mso-bidi-font-weight:normal'>Czy my�la� Pan/i, �e granie
sta�o si� dominuj�c� czynno�ci� w Pana/i �yciu codziennym? <input type="radio" name="gryInternetowe9a" value="1" checked> Tak
  <input type="radio" name="gryInternetowe9a" value="0"> Nie<o:p></o:p></b></span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-top:12.0pt;margin-right:0cm;
margin-bottom:0cm;margin-left:54.0pt;margin-bottom:.0001pt;mso-add-space:auto;
text-indent:-18.0pt;line-height:normal;mso-list:l1 level2 lfo1;mso-layout-grid-align:
none;text-autospace:none'><![if !supportLists]><span class=hps><b
style='mso-bidi-font-weight:normal'><span style='mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin'><span style='mso-list:Ignore'>b.<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span></b></span><![endif]><span
class=hps><b style='mso-bidi-font-weight:normal'>Czy czu� si� Pan/i
rozdra�niony, niespokojny lub nawet smutny kiedy pr�bowa� Pan/i ograniczy�
granie lub zaprzesta� grania?<span style='mso-spacerun:yes'>� </span><input type="radio" name="gryInternetowe10a" value="1" checked> Tak
  <input type="radio" name="gryInternetowe10a" value="0"> Nie<o:p></o:p></b></span></p>

<p class=MsoListParagraphCxSpLast style='margin-top:12.0pt;margin-right:0cm;
margin-bottom:0cm;margin-left:54.0pt;margin-bottom:.0001pt;mso-add-space:auto;
text-indent:-18.0pt;line-height:normal;mso-list:l1 level2 lfo1;mso-layout-grid-align:
none;text-autospace:none'><![if !supportLists]><span class=hps><b
style='mso-bidi-font-weight:normal'><span style='mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin'><span style='mso-list:Ignore'>c.<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span></b></span><![endif]><span
class=hps><b style='mso-bidi-font-weight:normal'>Czy odczuwa� Pan/i potrzeb�
sp�dzania coraz wi�kszej ilo�ci czasu na graniu w gry internetowe, aby uzyska�
satysfakcj� lub przyjemno��? <input type="radio" name="gryInternetowe11a" value="1" checked> Tak
  <input type="radio" name="gryInternetowe11a" value="0"> Nie<o:p></o:p></b></span></p>
<br>
<p class=Default style='margin-left:54.0pt;text-align:justify;text-indent:-18.0pt;
mso-list:l1 level2 lfo1'><![if !supportLists]><span class=hps><b
style='mso-bidi-font-weight:normal'><span style='font-size:11.0pt;font-family:
"Calibri","sans-serif";mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:
minor-latin;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin'><span
style='mso-list:Ignore'>d.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span></span></b></span><![endif]><span class=hps><b style='mso-bidi-font-weight:
normal'><span style='font-size:11.0pt;font-family:"Calibri","sans-serif";
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-font-family:
"Times New Roman";mso-bidi-theme-font:minor-bidi'>Czy podejmowa�/a Pan/i
nieskuteczne pr�by zaprzestania, zredukowania lub kontrolowania swojego udzia�u
w grach internetowych? </span></b></span><span class=hps><b style='mso-bidi-font-weight:
normal'><span style='font-size:11.0pt;font-family:"Calibri","sans-serif";
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin'><input type="radio" name="gryInternetowe12a" value="1" checked> Tak
  <input type="radio" name="gryInternetowe12a" value="0"> Nie</span></b></span><span
class=hps><b style='mso-bidi-font-weight:normal'><span style='font-size:11.0pt;
font-family:"Calibri","sans-serif";mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:
minor-latin;mso-bidi-font-family:"Times New Roman";mso-bidi-theme-font:minor-bidi'><o:p></o:p></span></b></span></p>
<br>
<p class=MsoListParagraphCxSpFirst style='margin-top:0cm;margin-right:0cm;
margin-bottom:0cm;margin-left:54.0pt;margin-bottom:.0001pt;mso-add-space:auto;
text-indent:-18.0pt;line-height:normal;mso-list:l1 level2 lfo1;mso-layout-grid-align:
none;text-autospace:none'><![if !supportLists]><span class=hps><b
style='mso-bidi-font-weight:normal'><span style='mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin'><span style='mso-list:Ignore'>e.<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span></b></span><![endif]><span
class=hps><b style='mso-bidi-font-weight:normal'>Czy straci�/a Pan/i
zainteresowanie swoimi wcze�niejszymi hobby i rozrywkami w wyniku swojej
aktywno�ci zwi�zanej z grami internetowymi? <input type="radio" name="gryInternetowe13a" value="1" checked> Tak
  <input type="radio" name="gryInternetowe13a" value="0"> Nie<o:p></o:p></b></span></p>
<br>
<p class=MsoListParagraphCxSpLast style='margin-top:0cm;margin-right:0cm;
margin-bottom:0cm;margin-left:54.0pt;margin-bottom:.0001pt;mso-add-space:auto;
text-indent:-18.0pt;line-height:normal;mso-list:l1 level2 lfo1;mso-layout-grid-align:
none;text-autospace:none'><![if !supportLists]><span class=hps><b
style='mso-bidi-font-weight:normal'><span style='mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin'><span style='mso-list:Ignore'>f.<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span></span></b></span><![endif]><span class=hps><b style='mso-bidi-font-weight:
normal'>Czy kontynuuje Pan/i granie w gry internetowe pomimo tego, �e wie
Pan/i, �e wywo�uje to problemy pomi�dzy Panem/<span class=SpellE>i�</span> a
innymi osobami? <input type="radio" name="gryInternetowe14a" value="1" checked> Tak
  <input type="radio" name="gryInternetowe14a" value="0"> Nie<o:p></o:p></b></span></p>

<h3 style='margin-left:54.0pt;text-indent:-18.0pt;mso-list:l1 level2 lfo1;
mso-layout-grid-align:none;text-autospace:none'><![if !supportLists]><span
class=hps><span style='font-size:11.0pt;font-family:"Calibri","sans-serif";
mso-ascii-theme-font:minor-latin;mso-fareast-font-family:Calibri;mso-fareast-theme-font:
minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;mso-fareast-language:EN-US;mso-bidi-font-weight:
normal'><span style='mso-list:Ignore'>g.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span></span></span><![endif]><span class=hps><span style='font-size:
11.0pt;font-family:"Calibri","sans-serif";mso-ascii-theme-font:minor-latin;
mso-fareast-font-family:Calibri;mso-fareast-theme-font:minor-latin;mso-hansi-theme-font:
minor-latin;mso-bidi-font-family:"Times New Roman";mso-bidi-theme-font:minor-bidi;
mso-fareast-language:EN-US;mso-bidi-font-weight:normal'>Czy ok�amywa�/a Pan/i
cz�onk�w rodziny, przyjaci�, terapeut�w lub znajomych co do ilo�ci czasu
sp�dzanego na korzystaniu z gier internetowych?</span></span><span class=hps><span
style='font-size:11.0pt;font-family:"Calibri","sans-serif";mso-ascii-theme-font:
minor-latin;mso-hansi-theme-font:minor-latin'> <input type="radio" name="gryInternetowe15a" value="1" checked> Tak
  <input type="radio" name="gryInternetowe15a" value="0"> Nie</span></span><span
class=hps><span style='font-size:11.0pt;font-family:"Calibri","sans-serif";
mso-ascii-theme-font:minor-latin;mso-fareast-font-family:Calibri;mso-fareast-theme-font:
minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-font-family:"Times New Roman";
mso-bidi-theme-font:minor-bidi;mso-fareast-language:EN-US;mso-bidi-font-weight:
normal'> <o:p></o:p></span></span></h3>

<h3 style='margin-left:54.0pt;text-indent:-18.0pt;mso-list:l1 level2 lfo1;
tab-stops:93.75pt;mso-layout-grid-align:none;text-autospace:none'><![if !supportLists]><span
class=hps><span style='font-size:11.0pt;font-family:"Calibri","sans-serif";
mso-ascii-theme-font:minor-latin;mso-fareast-font-family:Calibri;mso-fareast-theme-font:
minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;mso-fareast-language:EN-US;mso-bidi-font-weight:
normal'><span style='mso-list:Ignore'>h.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span></span></span><![endif]><span class=hps><span style='font-size:
11.0pt;font-family:"Calibri","sans-serif";mso-ascii-theme-font:minor-latin;
mso-fareast-font-family:Calibri;mso-fareast-theme-font:minor-latin;mso-hansi-theme-font:
minor-latin;mso-bidi-font-family:"Times New Roman";mso-bidi-theme-font:minor-bidi;
mso-fareast-language:EN-US;mso-bidi-font-weight:normal'>Czy gra�/a Pan/i w gry
internetowe, aby chwilowo uciec od problem�w lub przynie�� sobie ulg� od
negatywnego nastroju (np. poczucia bezradno�ci, winy, niepokoju)?</span></span><span
class=hps><span style='font-size:11.0pt;font-family:"Calibri","sans-serif";
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin'> <input type="radio" name="gryInternetowe16a" value="1" checked> Tak
  <input type="radio" name="gryInternetowe16a" value="0"> Nie</span></span><span
class=hps><span style='font-size:11.0pt;font-family:"Calibri","sans-serif";
mso-ascii-theme-font:minor-latin;mso-fareast-font-family:Calibri;mso-fareast-theme-font:
minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-font-family:"Times New Roman";
mso-bidi-theme-font:minor-bidi;mso-fareast-language:EN-US;mso-bidi-font-weight:
normal'><o:p></o:p></span></span></h3>

<h3 style='margin-left:54.0pt;text-indent:-18.0pt;mso-list:l1 level2 lfo1;
mso-layout-grid-align:none;text-autospace:none'><![if !supportLists]><span
class=hps><span style='font-size:11.0pt;font-family:"Calibri","sans-serif";
mso-ascii-theme-font:minor-latin;mso-fareast-font-family:Calibri;mso-fareast-theme-font:
minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin;mso-fareast-language:EN-US;mso-bidi-font-weight:
normal'><span style='mso-list:Ignore'>i.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span></span></span><![endif]><span class=hps><span style='font-size:
11.0pt;font-family:"Calibri","sans-serif";mso-ascii-theme-font:minor-latin;
mso-fareast-font-family:Calibri;mso-fareast-theme-font:minor-latin;mso-hansi-theme-font:
minor-latin;mso-bidi-font-family:"Times New Roman";mso-bidi-theme-font:minor-bidi;
mso-fareast-language:EN-US;mso-bidi-font-weight:normal'>Czy w wyniku
korzystania z gier internetowych nara�a�/a si� Pan/i lub utraci�/a Pan/i wa�n�
relacj�, prac�, szanse edukacyjne lub zawodowe? </span></span><span class=hps><span
style='font-size:11.0pt;font-family:"Calibri","sans-serif";mso-ascii-theme-font:
minor-latin;mso-hansi-theme-font:minor-latin'><input type="radio" name="gryInternetowe17a" value="1" checked> Tak
  <input type="radio" name="gryInternetowe17a" value="0"> Nie</span></span><span
class=hps><span style='font-size:11.0pt;font-family:"Calibri","sans-serif";
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-font-family:
"Times New Roman";mso-bidi-theme-font:minor-bidi;mso-fareast-language:EN-US;
mso-bidi-font-weight:normal'><o:p></o:p></span></span></h3>



<b style='mso-bidi-font-weight:normal'><span lang=EN-US style='font-size:11.0pt;
line-height:115%;font-family:"Calibri","sans-serif";mso-ascii-theme-font:minor-latin;
mso-fareast-font-family:Calibri;mso-fareast-theme-font:minor-latin;mso-hansi-theme-font:
minor-latin;mso-bidi-font-family:Times;mso-ansi-language:EN-US;mso-fareast-language:
EN-US;mso-bidi-language:AR-SA'><br clear=all style='mso-special-character:line-break;
page-break-before:always'>
</span></b>



<div style='mso-element:para-border-div;border-top:solid windowtext 1.0pt;
border-left:none;border-bottom:solid windowtext 1.0pt;border-right:none;
mso-border-top-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;
padding:1.0pt 0cm 1.0pt 0cm;background:#C6D9F1;mso-background-themecolor:text2;
mso-background-themetint:51'>
<br>
<p class=MsoNormal align=center style='text-align:center;line-height:normal;
background:#C6D9F1;mso-background-themecolor:text2;mso-background-themetint:
51;border:none;mso-border-top-alt:solid windowtext .5pt;mso-border-bottom-alt:
solid windowtext .5pt;padding:0cm;mso-padding-alt:1.0pt 0cm 1.0pt 0cm'><b
style='mso-bidi-font-weight:normal'><span lang=EN-US style='mso-bidi-font-family:
Times;mso-ansi-language:EN-US'>GAS<o:p></o:p></span></b></p>

</div>

<p class=MsoNormal>Poni�sze pytania odnosz� si� do Pana/i do�wiadcze�
dotycz�cych grania w gry internetowe w ci�gu ostatnich sze�ciu miesi�cy.</p>

<p class=MsoNormal>Prosz� zaznaczy� jak cz�sto w ci�gu ostatnich sze�ciu
miesi�cy ...<b style='mso-bidi-font-weight:normal'><span style='mso-bidi-font-family:
Times'><o:p></o:p></span></b></p>

<table class=MsoTableGrid border=1 cellspacing=0 cellpadding=0
 style='border-collapse:collapse;border:none;mso-border-alt:solid windowtext .5pt;
 mso-yfti-tbllook:1184;mso-padding-alt:0cm 5.4pt 0cm 5.4pt'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;height:26.55pt'>
  <td width=315 valign=top style='width:236.05pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:26.55pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal;mso-layout-grid-align:none;text-autospace:none'><span
  style='mso-bidi-font-family:Arial'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal;mso-layout-grid-align:none;text-autospace:none'><span
  style='mso-bidi-font-family:Arial'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=61 valign=top style='width:45.65pt;border:solid windowtext 1.0pt;
  border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
  solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:26.55pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal'><span style='mso-bidi-font-family:Arial;mso-bidi-font-weight:bold'>Nigdy</span><span
  lang=FR style='mso-bidi-font-family:Arial;mso-ansi-language:FR'><o:p></o:p></span></p>
  </td>
  <td width=61 valign=top style='width:45.65pt;border:solid windowtext 1.0pt;
  border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
  solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:26.55pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal;mso-layout-grid-align:none;text-autospace:none'><span
  style='mso-bidi-font-family:Arial;mso-bidi-font-weight:bold'>Rzadko</span><span
  lang=FR style='mso-bidi-font-family:Arial;mso-ansi-language:FR'><o:p></o:p></span></p>
  </td>
  <td width=61 valign=top style='width:45.7pt;border:solid windowtext 1.0pt;
  border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
  solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:26.55pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal;mso-layout-grid-align:none;text-autospace:none'><span
  style='mso-bidi-font-family:Arial;mso-bidi-font-weight:bold'>Czasem</span><span
  style='mso-fareast-font-family:"Times New Roman";mso-bidi-font-family:Arial;
  mso-fareast-language:PL'><o:p></o:p></span></p>
  </td>
  <td width=61 valign=top style='width:45.65pt;border:solid windowtext 1.0pt;
  border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
  solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:26.55pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal;mso-layout-grid-align:none;text-autospace:none'><span
  style='mso-bidi-font-family:Arial;mso-bidi-font-weight:bold'>Cz�sto<o:p></o:p></span></p>
  </td>
  <td width=61 valign=top style='width:45.7pt;border:solid windowtext 1.0pt;
  border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
  solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:26.55pt'>
  <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal;mso-layout-grid-align:none;text-autospace:none'><span
  style='mso-bidi-font-family:Arial;mso-bidi-font-weight:bold'>Bardzo cz�sto<o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:1'>
  <td width=315 valign=top style='width:236.05pt;border:solid windowtext 1.0pt;
  border-top:none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoListParagraphCxSpFirst style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:18.0pt;margin-bottom:.0001pt;mso-add-space:
  auto;text-indent:-18.0pt;line-height:normal;mso-list:l13 level1 lfo11;
  mso-layout-grid-align:none;text-autospace:none'><![if !supportLists]><span
  style='mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin'><span
  style='mso-list:Ignore'>1.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  </span></span></span><![endif]>� my�la�a�/e� o graniu w gr� przez ca�y dzie�?</p>
  </td>
  <td width=61 valign=top style='width:45.65pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
 <input type="radio" name="GAS1" value="1" checked> 
  </td>
  <td width=61 valign=top style='width:45.65pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
 <input type="radio" name="GAS1" value="2"> 
  </td>
  <td width=61 valign=top style='width:45.7pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
 <input type="radio" name="GAS1" value="3"> 
  </td>
  <td width=61 valign=top style='width:45.65pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <input type="radio" name="GAS1" value="4"> 
  </td>
  <td width=61 valign=top style='width:45.7pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <input type="radio" name="GAS1" value="5">
  </td>
 </tr>
 <tr style='mso-yfti-irow:2'>
  <td width=315 valign=top style='width:236.05pt;border:solid windowtext 1.0pt;
  border-top:none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoListParagraphCxSpFirst style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:18.0pt;margin-bottom:.0001pt;mso-add-space:
  auto;text-indent:-18.0pt;line-height:normal;mso-list:l13 level1 lfo11;
  mso-layout-grid-align:none;text-autospace:none'><![if !supportLists]><span
  style='mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin'><span
  style='mso-list:Ignore'>2.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  </span></span></span><![endif]>� sp�dza�a�/e� coraz wi�ksz� ilo�� czasu na
  graniu?</p>
  </td>
  <td width=61 valign=top style='width:45.65pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <input type="radio" name="GAS2" value="1" checked><span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;
  </span></span></span><![endif]>
  </td>
  <td width=61 valign=top style='width:45.65pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
 <input type="radio" name="GAS2" value="2"> 
  </td>
  <td width=61 valign=top style='width:45.7pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <input type="radio" name="GAS2" value="3"><span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;
  </span></span></span><![endif]><span style='mso-bidi-font-family:Arial'>
  </td>
  <td width=61 valign=top style='width:45.65pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
 <input type="radio" name="GAS2" value="4">
  </td>
  <td width=61 valign=top style='width:45.7pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
 <input type="radio" name="GAS2" value="5">
  </td>
 </tr>
 <tr style='mso-yfti-irow:3'>
  <td width=315 valign=top style='width:236.05pt;border:solid windowtext 1.0pt;
  border-top:none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoListParagraphCxSpFirst style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:18.0pt;margin-bottom:.0001pt;mso-add-space:
  auto;text-indent:-18.0pt;line-height:normal;mso-list:l13 level1 lfo11;
  mso-layout-grid-align:none;text-autospace:none'><![if !supportLists]><span
  style='mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin'><span
  style='mso-list:Ignore'>3.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  </span></span></span><![endif]>� gra�a�/e� w gry, �eby zapomnie� o prawdziwym
  �yciu?</p>
  </td>
  <td width=61 valign=top style='width:45.65pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <input type="radio" name="GAS3" value="1" checked> 
  </td>
  <td width=61 valign=top style='width:45.65pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <input type="radio" name="GAS3" value="2">
  </td>
  <td width=61 valign=top style='width:45.7pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <input type="radio" name="GAS3" value="3">
  </td>
  <td width=61 valign=top style='width:45.65pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <input type="radio" name="GAS3" value="4">
  </td>
  <td width=61 valign=top style='width:45.7pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <input type="radio" name="GAS3" value="5">
  </td>
 </tr>
 <tr style='mso-yfti-irow:4'>
  <td width=315 valign=top style='width:236.05pt;border:solid windowtext 1.0pt;
  border-top:none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoListParagraphCxSpFirst style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:18.0pt;margin-bottom:.0001pt;mso-add-space:
  auto;text-indent:-18.0pt;line-height:normal;mso-list:l13 level1 lfo11;
  mso-layout-grid-align:none;text-autospace:none'><![if !supportLists]><span
  style='mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;
  mso-fareast-language:PL'><span style='mso-list:Ignore'>4.<span
  style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span><![endif]><span
  style='mso-fareast-font-family:"Times New Roman";mso-bidi-font-family:Arial;
  mso-fareast-language:PL'>� inne osoby bezskutecznie stara�y si� spowodowa�,
  �eby� mniej gra�/a w gry?<o:p></o:p></span></p>
  </td>
  <td width=61 valign=top style='width:45.65pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <input type="radio" name="GAS4" value="1" checked>
  </td>
  <td width=61 valign=top style='width:45.65pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <input type="radio" name="GAS4" value="2">
  </td>
  <td width=61 valign=top style='width:45.7pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <input type="radio" name="GAS4" value="3">
  </td>
  <td width=61 valign=top style='width:45.65pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <input type="radio" name="GAS4" value="4">
  </td>
  <td width=61 valign=top style='width:45.7pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <input type="radio" name="GAS4" value="5">
  </td>
 </tr>
 <tr style='mso-yfti-irow:5'>
  <td width=315 valign=top style='width:236.05pt;border:solid windowtext 1.0pt;
  border-top:none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoListParagraphCxSpFirst style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:18.0pt;margin-bottom:.0001pt;mso-add-space:
  auto;text-indent:-18.0pt;line-height:normal;mso-list:l13 level1 lfo11;
  mso-layout-grid-align:none;text-autospace:none'><![if !supportLists]><span
  style='mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin'><span
  style='mso-list:Ignore'>5.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  </span></span></span><![endif]>� czu�e� si� �le, kiedy nie by�a�/e� w stanie
  gra� w gry?</p>
  </td>
  <td width=61 valign=top style='width:45.65pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <input type="radio" name="GAS5" value="1" checked>
  </td>
  <td width=61 valign=top style='width:45.65pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <input type="radio" name="GAS5" value="2"> 
  </td>
  <td width=61 valign=top style='width:45.7pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <input type="radio" name="GAS5" value="3">
  </td>
  <td width=61 valign=top style='width:45.65pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <input type="radio" name="GAS5" value="4">
  </td>
  <td width=61 valign=top style='width:45.7pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <input type="radio" name="GAS5" value="5">
  </td>
 </tr>
 <tr style='mso-yfti-irow:6'>
  <td width=315 valign=top style='width:236.05pt;border:solid windowtext 1.0pt;
  border-top:none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoListParagraphCxSpFirst style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:18.0pt;margin-bottom:.0001pt;mso-add-space:
  auto;text-indent:-18.0pt;line-height:normal;mso-list:l13 level1 lfo11;
  mso-layout-grid-align:none;text-autospace:none'><![if !supportLists]><span
  style='mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin'><span
  style='mso-list:Ignore'>6.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  </span></span></span><![endif]><span style='mso-fareast-font-family:"Times New Roman";
  mso-bidi-font-family:Arial;mso-fareast-language:PL'>� k��ci�a�/e� si� z
  innymi (np. rodzina, przyjaciele) na temat czasu, jaki sp�dzasz na graniu?</span></p>
  </td>
  <td width=61 valign=top style='width:45.65pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
 <input type="radio" name="GAS6" value="1" checked> 
  </td>
  <td width=61 valign=top style='width:45.65pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
 <input type="radio" name="GAS6" value="2">
  </td>
  <td width=61 valign=top style='width:45.7pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
 <input type="radio" name="GAS6" value="3">
  </td>
  <td width=61 valign=top style='width:45.65pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <input type="radio" name="GAS6" value="4">
  </td>
  <td width=61 valign=top style='width:45.7pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <input type="radio" name="GAS6" value="5"> 
  </td>
 </tr>
 <tr style='mso-yfti-irow:7;mso-yfti-lastrow:yes'>
  <td width=315 valign=top style='width:236.05pt;border:solid windowtext 1.0pt;
  border-top:none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
  padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoListParagraphCxSpFirst style='margin-top:0cm;margin-right:0cm;
  margin-bottom:0cm;margin-left:18.0pt;margin-bottom:.0001pt;mso-add-space:
  auto;text-indent:-18.0pt;line-height:normal;mso-list:l13 level1 lfo11;
  mso-layout-grid-align:none;text-autospace:none'><![if !supportLists]><span
  style='mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin;
  mso-fareast-language:PL'><span style='mso-list:Ignore'>7.<span
  style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span><![endif]><span
  style='mso-fareast-font-family:"Times New Roman";mso-bidi-font-family:Arial;
  mso-fareast-language:PL'>� zaniedba�e� inne wa�ne czynno�ci (np. szko��,
  prac�, uprawianie sportu) aby gra� w gry?<o:p></o:p></span></p>
  </td>
  <td width=61 valign=top style='width:45.65pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <input type="radio" name="GAS7" value="1" checked>
  </td>
  <td width=61 valign=top style='width:45.65pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <input type="radio" name="GAS7" value="2">
  </td>
  <td width=61 valign=top style='width:45.7pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <input type="radio" name="GAS7" value="3"> 

  </td>
  <td width=61 valign=top style='width:45.65pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <input type="radio" name="GAS7" value="4">
  </td>
  <td width=61 valign=top style='width:45.7pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <input type="radio" name="GAS7" value="5">
  </td>
 </tr>
</table>

<p class=MsoNormal><b style='mso-bidi-font-weight:normal'><span
style='mso-bidi-font-family:Tahoma'><o:p>&nbsp;</o:p></span></b></p>

<div style='mso-element:para-border-div;border-top:solid windowtext 1.0pt;
border-left:none;border-bottom:solid windowtext 1.0pt;border-right:none;
mso-border-top-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;
padding:1.0pt 0cm 1.0pt 0cm;background:#C6D9F1;mso-background-themecolor:text2;
mso-background-themetint:51'>
<br>
<p class=MsoNormal align=center style='text-align:center;line-height:normal;
background:#C6D9F1;mso-background-themecolor:text2;mso-background-themetint:
51;border:none;mso-border-top-alt:solid windowtext .5pt;mso-border-bottom-alt:
solid windowtext .5pt;padding:0cm;mso-padding-alt:1.0pt 0cm 1.0pt 0cm'><b
style='mso-bidi-font-weight:normal'><span lang=FR style='mso-bidi-font-family:
Tahoma;mso-ansi-language:FR'>AUDIT <o:p></o:p></span></b></p>

</div>
<br>
<p class=MsoNormal style='mso-margin-top-alt:auto;mso-margin-bottom-alt:auto;
line-height:normal'><b><span style='font-size:12.0pt;mso-fareast-font-family:
"Times New Roman";mso-bidi-font-family:"Times New Roman";mso-fareast-language:
PL'>1.</span></b><span style='font-size:12.0pt;mso-fareast-font-family:"Times New Roman";
mso-bidi-font-family:"Times New Roman";mso-fareast-language:PL'> <b>Jak cz�sto
pije Pan/Pani napoje zawieraj�ce alkohol? </b><o:p></o:p></span></p>


 
 &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT1" value="1" checked> raz w
     miesi�cu lub rzadziej<br> 
 &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT1" value="2"> dwa do
     czterech razy w miesi�cu<br> 

 &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT1" value="3"> dwa lub
     trzy razy w tygodniu<br>
 &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT1" value="4"> cztery lub
     wi�cej razy w tygodniu<br>
<br>
<p class=MsoNormal style='mso-margin-top-alt:auto;mso-margin-bottom-alt:auto;
line-height:normal'><b><span style='font-size:12.0pt;mso-fareast-font-family:
"Times New Roman";mso-bidi-font-family:"Times New Roman";mso-fareast-language:
PL'>2.</span></b><span style='font-size:12.0pt;mso-fareast-font-family:"Times New Roman";
mso-bidi-font-family:"Times New Roman";mso-fareast-language:PL'> <b>Ile
standardowych porcji zawieraj�cych alkohol wypija Pan/Pani w dniu, w kt�rym
Pan/Pani pije?</b><o:p></o:p></span></p>


 &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT2" value="0" checked> nigdy <br>
 &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT2" value="1" > 1-2 porcje<br> 
 &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT2" value="2"> 3-4 porcje<br> 

 &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT2" value="3"> 5-6 porcji<br>
 
 &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT2  value="4"> 7-9 porcji<br>
 &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT2" value="5"> 10 lub
     wi�cej porcji<br>


<br>
<p class=MsoNormal style='mso-margin-top-alt:auto;mso-margin-bottom-alt:auto;
line-height:normal'><b><span style='font-size:12.0pt;mso-fareast-font-family:
"Times New Roman";mso-bidi-font-family:"Times New Roman";mso-fareast-language:
PL'>3.</span></b><span style='font-size:12.0pt;mso-fareast-font-family:"Times New Roman";
mso-bidi-font-family:"Times New Roman";mso-fareast-language:PL'> <b>Jak cz�sto
wypija Pan/Pani sze�� lub wi�cej porcji alkoholu podczas jednego dnia? </b><o:p></o:p></span></p>


  &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT3" value="0" checked> nigdy <br>
  &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT3" value="1"> rzadziej
     ni� jeden raz w miesi�cu<br> 
  &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT3" value="2"> oko�o raz
     w miesi�cu<br> 

  &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT3" value="3"> oko�o raz
     w tygodniu<br>
  &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT3" value="4"> codziennie
     lub prawie codziennie<br>

<br>
<p class=MsoNormal style='mso-margin-top-alt:auto;mso-margin-bottom-alt:auto;
line-height:normal'><b><span style='font-size:12.0pt;mso-fareast-font-family:
"Times New Roman";mso-bidi-font-family:"Times New Roman";mso-fareast-language:
PL'>4.</span></b><span style='font-size:12.0pt;mso-fareast-font-family:"Times New Roman";
mso-bidi-font-family:"Times New Roman";mso-fareast-language:PL'> <b>Jak cz�sto
w ostatnim roku nie m�g� Pan/Pani zaprzesta� picia po jego rozpocz�ciu? </b><o:p></o:p></span></p>


  &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT4" value="0" checked> nigdy<br>
  &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT4" value="1"> rzadziej
     ni� jeden raz w miesi�cu<br> 
  &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT4" value="2"> oko�o raz
     w miesi�cu<br> 

  &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT4" value="3"> oko�o raz
     w tygodniu<br>
  &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT4" value="4"> codziennie
     lub prawie codziennie<br>

<br>
<p class=MsoNormal style='mso-margin-top-alt:auto;mso-margin-bottom-alt:auto;
line-height:normal'><b><span style='font-size:12.0pt;mso-fareast-font-family:
"Times New Roman";mso-bidi-font-family:"Times New Roman";mso-fareast-language:
PL'>5.</span></b><span style='font-size:12.0pt;mso-fareast-font-family:"Times New Roman";
mso-bidi-font-family:"Times New Roman";mso-fareast-language:PL'> <b>Jak cz�sto
w ci�gu ostatniego roku z powodu picia alkoholu zrobi� Pan/Pani co�
niew�a�ciwego, co naruszy�o przyj�te w Pana/Pani �rodowisku normy post�powania?
</b><o:p></o:p></span></p>


  &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT5" value="0" checked> nigdy<br>
  &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT5" value="1"> rzadziej
     ni� jeden raz w miesi�cu<br> 
  &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT5" value="2"> oko�o raz
     w miesi�cu<br> 

  &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT5" value="3"> oko�o raz
     w tygodniu<br>
  &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT5" value="4"> codziennie
     lub prawie codziennie<br>
<br>
<p class=MsoNormal style='mso-margin-top-alt:auto;mso-margin-bottom-alt:auto;
line-height:normal'><span style='font-size:12.0pt;mso-fareast-font-family:"Times New Roman";
mso-bidi-font-family:"Times New Roman";mso-fareast-language:PL'><b>6. Jak
cz�sto w ostatnim roku potrzebowa� Pan/Pani napi� si� alkoholu rano nast�pnego
dnia po &quot;du�ym piciu&quot;, aby m�c doj�� do siebie? </b><o:p></o:p></span></p>


  &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT6" value="0" checked> nigdy<br>
  &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT6" value="1"> rzadziej
     ni� jeden raz w miesi�cu<br> 
 &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT6" value="2"> oko�o raz
     w miesi�cu<br> 

  &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT6" value="3"> oko�o raz
     w tygodniu<br>
  &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT6" value="4"> codziennie
     lub prawie codziennie<br>


<br>
<p class=MsoNormal style='mso-margin-top-alt:auto;mso-margin-bottom-alt:auto;
line-height:normal'><b><span style='font-size:12.0pt;mso-fareast-font-family:
"Times New Roman";mso-bidi-font-family:"Times New Roman";mso-fareast-language:
PL'>7. Jak cz�sto w ostatnim roku mia� Pan/Pani poczucie winy lub wyrzuty
sumienia po piciu alkoholu? </span></b><span style='font-size:12.0pt;
mso-fareast-font-family:"Times New Roman";mso-bidi-font-family:"Times New Roman";
mso-fareast-language:PL'><o:p></o:p></span></p>



  &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT7" value="0" checked> nigdy<br>
  &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT7" value="1"> rzadziej
     ni� jeden raz w miesi�cu<br> 
 &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT7" value="2"> oko�o raz
     w miesi�cu<br> 

  &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT7" value="3"> oko�o raz
     w tygodniu<br>
  &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT7" value="4"> codziennie
     lub prawie codziennie<br>


<br>
<p class=MsoNormal style='mso-margin-top-alt:auto;mso-margin-bottom-alt:auto;
line-height:normal'><b><span style='font-size:12.0pt;mso-fareast-font-family:
"Times New Roman";mso-bidi-font-family:"Times New Roman";mso-fareast-language:
PL'>8. Jak cz�sto w ostatnim roku nie m�g� Pan/Pani przypomnie� sobie, co
zdarzy�o <span class=SpellE>sie</span> poprzedniego dnia lub nocy, z powodu
picia? </span></b><span style='font-size:12.0pt;mso-fareast-font-family:"Times New Roman";
mso-bidi-font-family:"Times New Roman";mso-fareast-language:PL'><o:p></o:p></span></p>


  &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT8" value="0" checked> nigdy<br>
  &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT8" value="1"> rzadziej
     ni� jeden raz w miesi�cu<br> 
  &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT8" value="2"> oko�o raz
     w miesi�cu<br> 

  &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT8" value="3"> oko�o raz
     w tygodniu<br>
  &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT8" value="4"> codziennie
     lub prawie codziennie<br>
<br>
<p class=MsoNormal style='mso-margin-top-alt:auto;mso-margin-bottom-alt:auto;
line-height:normal'><b><span style='font-size:12.0pt;mso-fareast-font-family:
"Times New Roman";mso-bidi-font-family:"Times New Roman";mso-fareast-language:
PL'>9.</span></b><span style='font-size:12.0pt;mso-fareast-font-family:"Times New Roman";
mso-bidi-font-family:"Times New Roman";mso-fareast-language:PL'> <b>Czy
kiedykolwiek Pan/Pani lub kto� inny dozna� jakiego� urazu fizycznego w wyniku
Pana/Pani picia? </b><o:p></o:p></span></p>



  &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT9" value="0" checked> nie<br>
  &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT9" value="2"> tak, ale
     nie w ostatnim roku<br> 
  &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT9" value="4"> tak, w
     ostatnim roku<br> 

  
<br>
<p class=MsoNormal style='mso-margin-top-alt:auto;mso-margin-bottom-alt:auto;
line-height:normal'><b><span style='font-size:12.0pt;mso-fareast-font-family:
"Times New Roman";mso-bidi-font-family:"Times New Roman";mso-fareast-language:
PL'>10.</span></b><span style='font-size:12.0pt;mso-fareast-font-family:"Times New Roman";
mso-bidi-font-family:"Times New Roman";mso-fareast-language:PL'> <b>Czy kto� z
rodziny, lekarzy lub innych pracownik�w s�u�by zdrowia interesowa� si�
Pana/Pani piciem albo sugerowa� jego ograniczenie? </b><o:p></o:p></span></p>


  &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT10" value="0" checked> nie<br>
  &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT10" value="2"> tak, ale
     nie w ostatnim roku<br> 
  &nbsp;&nbsp;&nbsp;<input type="radio" name="AUDIT10" value="4"> tak, w
     ostatnim roku<br> 
	 <br>
<div style='mso-element:para-border-div;border-top:solid windowtext 1.0pt;
border-left:none;border-bottom:solid windowtext 1.0pt;border-right:none;
mso-border-top-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;
padding:1.0pt 0cm 0cm 0cm;background:#C6D9F1;mso-background-themecolor:text2;
mso-background-themetint:51'>
<br>
<p class=MsoNormal align=center style='text-align:center;background:#C6D9F1;
mso-background-themecolor:text2;mso-background-themetint:51;border:none;
mso-border-top-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;
padding:0cm;mso-padding-alt:1.0pt 0cm 0cm 0cm'><b style='mso-bidi-font-weight:
normal'><span lang=EN-US style='mso-bidi-font-family:Tahoma;mso-ansi-language:
EN-US'>ASSIST<o:p></o:p></span></b></p>

</div>
<br>
<p class=MsoListParagraphCxSpFirst style='margin-top:0cm;margin-right:0cm;
margin-bottom:0cm;margin-left:18.0pt;margin-bottom:.0001pt;mso-add-space:auto;
text-indent:-18.0pt;line-height:normal;mso-list:l23 level1 lfo36;mso-layout-grid-align:
none;text-autospace:none'><![if !supportLists]><b style='mso-bidi-font-weight:
normal'><span lang=FR style='mso-bidi-font-family:Calibri;mso-bidi-theme-font:
minor-latin;mso-ansi-language:FR'><span style='mso-list:Ignore'>1.<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span></b><![endif]><b
style='mso-bidi-font-weight:normal'><span lang=FR style='mso-bidi-font-family:
KvhlnfTimesNewRomanPSMT;mso-ansi-language:FR'>W ci�gu ostatnich 3 miesi�cy jak
cz�sto u�ywa�/a Pan/i marihuan�?<o:p></o:p></span></b></p>
<br>

  &nbsp;&nbsp;&nbsp;<input type="radio" name="ASSIST1" value="0" checked> nigdy<br>
  &nbsp;&nbsp;&nbsp;<input type="radio" name="ASSIST1" value="2"> 1 lub 2raz<br> 
  &nbsp;&nbsp;&nbsp;<input type="radio" name="ASSIST1" value="3"> 1 raz na
miesi�c<br> 
 &nbsp;&nbsp;&nbsp;<input type="radio" name="ASSIST1" value="4"> raz na
tydzie�<br> 
&nbsp;&nbsp;&nbsp;<input type="radio" name="ASSIST1" value="6"> ka�dego
dnia lub prawie ka�dego dnia<br> 
<br>
<p class=MsoListParagraphCxSpFirst style='margin-top:0cm;margin-right:0cm;
margin-bottom:0cm;margin-left:18.0pt;margin-bottom:.0001pt;mso-add-space:auto;
text-indent:-18.0pt;line-height:normal;mso-list:l23 level1 lfo36;mso-layout-grid-align:
none;text-autospace:none'><![if !supportLists]><b style='mso-bidi-font-weight:
normal'><span lang=FR style='mso-bidi-font-family:Calibri;mso-bidi-theme-font:
minor-latin;mso-ansi-language:FR'><span style='mso-list:Ignore'>2.<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span></b><![endif]><b
style='mso-bidi-font-weight:normal'><span lang=FR style='mso-bidi-font-family:
TTE10FF940t00;mso-ansi-language:FR'>W ci�gu ostatnich 3 miesi�cy jak cz�sto
mia�/a Pan/i silne pragnienie lub siln� potrzeb� u�ywania marihuany?<o:p></o:p></span></b></p>
<br>

  &nbsp;&nbsp;&nbsp;<input type="radio" name="ASSIST2" value="0" checked> nigdy<br>
    &nbsp;&nbsp;&nbsp;<input type="radio" name="ASSIST2" value="3"> 1 lub 2raz<br> 
  &nbsp;&nbsp;&nbsp;<input type="radio" name="ASSIST2" value="4"> 1 raz na
miesi�c<br> 
 &nbsp;&nbsp;&nbsp;<input type="radio" name="ASSIST2" value="5"> raz na
tydzie�<br> 
&nbsp;&nbsp;&nbsp;<input type="radio" name="ASSIST2" value="6"> ka�dego
dnia lub prawie ka�dego dnia<br> 
<br>
<p style='margin-top:5.0pt;margin-right:0cm;margin-bottom:0cm;margin-left:18.0pt;
margin-bottom:.0001pt;text-indent:-18.0pt;mso-list:l23 level1 lfo36'><![if !supportLists]><b
style='mso-bidi-font-weight:normal'><span style='font-size:11.0pt;font-family:
"Calibri","sans-serif";mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:
minor-latin;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin'><span
style='mso-list:Ignore'>3.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span></span></b><![endif]><b><span style='font-size:11.0pt;font-family:
"Calibri","sans-serif";mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:
minor-latin'>W ci�gu ostatnich 3 miesi�cy jak cz�sto u�ywanie przez Pana/<span
class=SpellE>i�</span> marihuany doprowadzi�o do wyst�pienia problem�w zdrowotnych,
spo�ecznych, prawnych lub finansowych?</span></b><b style='mso-bidi-font-weight:
normal'><span style='font-size:11.0pt;font-family:"Calibri","sans-serif";
mso-ascii-theme-font:minor-latin;mso-hansi-theme-font:minor-latin'><o:p></o:p></span></b></p>
<br>

  &nbsp;&nbsp;&nbsp;<input type="radio" name="ASSIST3" value="0" checked> nigdy<br>
  &nbsp;&nbsp;&nbsp;<input type="radio" name="ASSIST3" value="4"> 1 lub 2raz<br>
  &nbsp;&nbsp;&nbsp;<input type="radio" name="ASSIST3" value="5"> 1 raz na
miesi�c<br> 
 &nbsp;&nbsp;&nbsp;<input type="radio" name="ASSIST3" value="6"> raz na
tydzie�<br> 
&nbsp;&nbsp;&nbsp;<input type="radio" name="ASSIST3" value="7"> ka�dego
dnia lub prawie ka�dego dnia<br> 
<br>

<p style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;margin-left:18.0pt;
margin-bottom:.0001pt;text-indent:-18.0pt;mso-list:l23 level1 lfo36'><![if !supportLists]><b><span
style='font-size:11.0pt;font-family:"Calibri","sans-serif";mso-ascii-theme-font:
minor-latin;mso-hansi-theme-font:minor-latin;mso-bidi-font-family:Calibri;
mso-bidi-theme-font:minor-latin'><span style='mso-list:Ignore'>4.<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span></b><![endif]><b><span
style='font-size:11.0pt;font-family:"Calibri","sans-serif";mso-ascii-theme-font:
minor-latin;mso-hansi-theme-font:minor-latin'>W ci�gu ostatnich 3 miesi�cy jak
cz�sto nie uda�o si� Panu/i wykona� tego, czego si� zwykle od Pani/a oczekuje z
powodu u�ywania marihuany?<o:p></o:p></span></b></p>
<br>

  &nbsp;&nbsp;&nbsp;<input type="radio" name="ASSIST4" value="0" checked> nigdy<br>
  &nbsp;&nbsp;&nbsp;<input type="radio" name="ASSIST4" value="5"> 1 lub 2raz<br>
  &nbsp;&nbsp;&nbsp;<input type="radio" name="ASSIST4" value="6"> tak raz na
miesi�c<br> 
 &nbsp;&nbsp;&nbsp;<input type="radio" name="ASSIST4" value="7"> raz na
tydzie�<br> 
&nbsp;&nbsp;&nbsp;<input type="radio" name="ASSIST4" value="8"> ka�dego
dnia lub prawie ka�dego dnia<br> 
<br>
<p class=MsoListParagraphCxSpFirst style='margin-top:0cm;margin-right:0cm;
margin-bottom:0cm;margin-left:18.0pt;margin-bottom:.0001pt;mso-add-space:auto;
text-indent:-18.0pt;line-height:normal;mso-list:l23 level1 lfo36;mso-layout-grid-align:
none;text-autospace:none'><![if !supportLists]><b style='mso-bidi-font-weight:
normal'><span lang=FR style='mso-bidi-font-family:Calibri;mso-bidi-theme-font:
minor-latin;mso-ansi-language:FR'><span style='mso-list:Ignore'>5.<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span></b><![endif]><b
style='mso-bidi-font-weight:normal'><span lang=FR style='mso-bidi-font-family:
TTE10FF940t00;mso-ansi-language:FR'>Czy Pana/i przyjaciel, cz�onek rodziny lub
ktokolwiek inny wyrazi� swoje zaniepokojenie u�ywaniem przez Pana/i�
marihuany?<o:p></o:p></span></b></p>
<br>

  &nbsp;&nbsp;&nbsp;<input type="radio" name="ASSIST5" value="0" checked> nie,
nigdy<br>
  &nbsp;&nbsp;&nbsp;<input type="radio" name="ASSIST5" value="6"> tak, w
ci�gu ostatnich 3 miesi�cy<br> 
 &nbsp;&nbsp;&nbsp;<input type="radio" name="ASSIST5" value="3"> tak,
ale nie w ci�gu ostatnich 3 miesi�cy<br> 
<br>
<p class=MsoListParagraphCxSpFirst style='margin-top:0cm;margin-right:0cm;
margin-bottom:0cm;margin-left:18.0pt;margin-bottom:.0001pt;mso-add-space:auto;
text-indent:-18.0pt;line-height:normal;mso-list:l23 level1 lfo36;mso-layout-grid-align:
none;text-autospace:none'><![if !supportLists]><b style='mso-bidi-font-weight:
normal'><span lang=FR style='mso-bidi-font-family:Calibri;mso-bidi-theme-font:
minor-latin;mso-ansi-language:FR'><span style='mso-list:Ignore'>6.<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span></b><![endif]><b
style='mso-bidi-font-weight:normal'><span lang=FR style='mso-bidi-font-family:
TTE10FF940t00;mso-ansi-language:FR'>Czy kiedykolwiek pr�bowa� Pan/i ograniczy�
lub zaprzesta� u�ywania marihuany, ale nie uda�o si� to Pani/u?<o:p></o:p></span></b></p>
<br>

  &nbsp;&nbsp;&nbsp;<input type="radio" name="ASSIST6" value="0" checked> nie,
nigdy<br>
  &nbsp;&nbsp;&nbsp;<input type="radio" name="ASSIST6" value="6"> tak, w
ci�gu ostatnich 3 miesi�cy<br> 
 &nbsp;&nbsp;&nbsp;<input type="radio" name="ASSIST6" value="3"> tak,
ale nie w ci�gu ostatnich 3 miesi�cy<br> 
</div>
 <br><br>
  <input type="submit" value="Dalej">
</form> 
</body>

</html>
