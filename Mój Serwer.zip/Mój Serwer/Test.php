﻿<!DOCTYPE html>
<html>
<body>

<?php

$tekst="Hello world world world!";

$tekst=preg_replace("/world/","Peter",$tekst,1);
echo $tekst;
$tekst=preg_replace("/world/","Peter",$tekst,1);
echo $tekst;
?>

</body>
</html>