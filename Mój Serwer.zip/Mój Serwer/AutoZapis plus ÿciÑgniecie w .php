
<?php
require_once '../PHPWord.php';

// New Word Document
$PHPWord = new PHPWord();

// New portrait section
$section = $PHPWord->createSection();

// Add text elements
$section->addText($_GET['Tekst']);


// Save File
$objWriter = PHPWord_IOFactory::createWriter($PHPWord, 'Word2007');
$objWriter->save('Text.docx');


$File=file('Text.docx');
//auto ściąganie

header('Content-type: application/octet-stream');
header('Content-Disposition: attachment; filename=Text.docx');
header('Pragma: no-cache');
readfile("Text.docx");

unlink("Text.docx");
//header('Content-type: application/octet-stream');
//header('Content-Disposition: attachment; filename="Text.docx"');
//header("Connection: close");
?>